// types.ts

/**
 * Represents the four cardinal directions.
 */
export type Direction = 'N' | 'S' | 'E' | 'W';

/**
 * Represents the neighbors of a geographical feature in the four cardinal directions.
 * Each direction maps to the `feature_id` of the neighboring feature or a descriptive string for a boundary (e.g., "Bay of Bengal Boundary").
 * A null value indicates no neighbor in that direction (e.g., beyond map scope or an ocean).
 */
export interface Neighbors {
  N: string | null;
  S: string | null;
  E: string | null;
  W: string | null;
}

/**
 * Represents a single geographical feature (country, state, or district)
 * with its associated data for navigation and announcements.
 */
export interface Feature {
  feature_id: string; // Unique Identifier (e.g., Census Code or ISO code).
  name: string; // Standard, familiar place name (e.g., "Gujarat State").
  centroid: [number, number]; // [Latitude, Longitude] for detail announcement and sonification origin.
  description_5pt: string[]; // 5 curriculum-relevant, pre-generated facts.
  neighbors: Neighbors; // Dictionary mapping the four cardinal directions to neighbor IDs/Names.
  boundary_type: 'Country' | 'State' | 'District' | 'Ocean' | 'Sea' | 'River' | 'MountainRange'; // "Country," "State," "District," or new geographical feature types.
}

/**
 * Defines the different levels of detail available in the map.
 */
export enum MapLevel {
  WORLD = 'World',
  INDIA_STATES = 'India States',
  INDIA_DISTRICTS = 'India Districts',
}

/**
 * Represents the configuration for playing a directional sound.
 */
export interface DirectionalSoundConfig {
  direction: Direction;
  audioContext: AudioContext;
  panner: PannerNode;
  gainNode: GainNode;
}

/**
 * Represents general audio parameters.
 */
export interface AudioParams {
  gain: number;
  frequency: number;
  duration: number;
  qFactor: number;
  delay: number;
  boundaryFrequency: number;
  oceanAmbientFrequency: number; // New: Frequency for ocean ambient sound
  riverFrequency: number;       // New: Frequency for river sound
  mountainFrequency: number;    // New: Frequency for mountain range sound
}