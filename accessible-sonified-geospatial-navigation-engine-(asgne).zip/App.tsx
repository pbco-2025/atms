// App.tsx
import React, { useState, useEffect } from 'react';
import MapGrid from './components/MapGrid';
import { audioEngine } from './services/audioService';

const App: React.FC = () => {
  const [audioInitialized, setAudioInitialized] = useState(false);

  const handleAudioInit = () => {
    setAudioInitialized(true);
  };

  // Cleanup audio engine on component unmount
  useEffect(() => {
    return () => {
      audioEngine.stopAll();
    };
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-gray-900 text-gray-100">
      <header className="p-4 bg-gray-800 shadow-md">
        <h1 className="text-xl md:text-2xl font-bold text-center text-indigo-300">
          Accessible Sonified Geospatial Navigation Engine
        </h1>
      </header>
      <main className="flex-grow flex items-center justify-center p-4">
        <MapGrid onAudioInit={handleAudioInit} />
      </main>
      <footer className="p-4 text-center text-gray-500 text-sm bg-gray-800">
        © {new Date().getFullYear()} ASGNE Project. Designed for WCAG 2.2 AA Accessibility.
      </footer>
    </div>
  );
};

export default App;