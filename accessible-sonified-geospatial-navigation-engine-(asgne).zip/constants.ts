// constants.ts
import { MapLevel, AudioParams } from './types';

export const INITIAL_MAP_LEVEL: MapLevel = MapLevel.WORLD;

export const AUDIO_PARAMS: AudioParams = {
  gain: 0.05, // General volume for sounds
  frequency: 880, // Base frequency for directional tones (A5)
  duration: 0.1, // Duration of directional sounds in seconds
  qFactor: 10, // Q-factor for bandpass filter, higher for more resonant sound
  delay: 0.05, // Small delay for panner position update before playing sound
  boundaryFrequency: 440, // Frequency for boundary hit warning (A4)
  oceanAmbientFrequency: 110, // A2 - Low hum for ocean
  riverFrequency: 660, // E5 - Flowing sound for river
  mountainFrequency: 220, // A3 - Deep, resonant sound for mountains
};

// Constants for geographical positioning
export const MAP_DISPLAY_WIDTH = 3000; // Increased width for coordinate mapping (pixels)
export const MAP_DISPLAY_HEIGHT = 1600; // Increased height for coordinate mapping (pixels)
export const CELL_WIDTH = 100; // Fixed width for country cells (pixels)
export const CELL_HEIGHT = 50; // Fixed height for country cells (pixels)