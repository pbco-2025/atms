// components/MapGrid.tsx
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Feature, MapLevel, Direction } from '../types';
import { audioEngine } from '../services/audioService';
import { geoDataService } from '../services/geoDataService';
import { geminiService } from '../services/geminiService';
import FeatureCell from './FeatureCell';
import { MAP_DISPLAY_WIDTH, MAP_DISPLAY_HEIGHT, CELL_WIDTH, CELL_HEIGHT } from '../constants';

interface MapGridProps {
  onAudioInit: () => void;
}

// Function to normalize latitude and longitude to pixel coordinates
// This is a simplified Mercator-like projection for display on a flat grid
const normalizeCoordinates = (latitude: number, longitude: number) => {
  // Latitude: -90 (South) to 90 (North) -> Y-axis (0 at top, height at bottom)
  // Longitude: -180 (West) to 180 (East) -> X-axis (0 at left, width at right)

  // Scale latitude (Y)
  // Map latitude from [-90, 90] to [0, 1]
  const normalizedLat = (latitude + 90) / 180;
  // Invert Y for screen coordinates (0 at top, MAP_DISPLAY_HEIGHT at bottom)
  const y = MAP_DISPLAY_HEIGHT * (1 - normalizedLat);

  // Scale longitude (X)
  // Map longitude from [-180, 180] to [0, 1]
  const normalizedLng = (longitude + 180) / 360;
  const x = MAP_DISPLAY_WIDTH * normalizedLng;

  // Center the cell
  const top = y - CELL_HEIGHT / 2;
  const left = x - CELL_WIDTH / 2;

  return { top, left };
};

const MapGrid: React.FC<MapGridProps> = ({ onAudioInit }) => {
  const [currentMapLevel, setCurrentMapLevel] = useState<MapLevel>(MapLevel.WORLD);
  const [focusedFeatureId, setFocusedFeatureId] = useState<string | null>('ATL_OCN_N'); // Initial focus on North Atlantic Ocean
  const [features, setFeatures] = useState<Feature[]>([]);
  const [audioInitialized, setAudioInitialized] = useState(false);
  const [userInteracted, setUserInteracted] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [announcement, setAnnouncement] = useState<string>('');
  const [isLoadingSpeech, setIsLoadingSpeech] = useState(false);

  const mapGridRef = useRef<HTMLDivElement>(null);
  const initialLoadRef = useRef(true); // Ref to track initial load for setting focus

  // Live region element for screen reader announcements
  const liveRegionRef = useRef<HTMLDivElement>(null);

  // Helper to update live region safely
  const updateLiveRegion = useCallback((message: string) => {
    if (liveRegionRef.current) {
      liveRegionRef.current.textContent = message;
    }
  }, []);

  const ensureAudioInitialized = useCallback(() => {
    if (!audioInitialized && !userInteracted) {
      audioEngine.init();
      geminiService.initGenAI(); // Initialize GeminiService on first user interaction
      onAudioInit();
      setAudioInitialized(true);
      setUserInteracted(true);
      console.log('Audio context and GeminiService initialized by user interaction.');

      const initialFeature = geoDataService.getFeatureById(focusedFeatureId || '', currentMapLevel);
      const initialName = initialFeature ? initialFeature.name : 'the map';
      updateLiveRegion(`Welcome to the Accessible Sonified Geospatial Navigation Engine. Currently focused on ${initialName}. Use arrow keys to navigate. Press 'Enter' or 'Space' to zoom in, 'Backspace' to zoom out. Press 'D' for description, 'M' to mute/unmute.`);
    }
  }, [audioInitialized, userInteracted, onAudioInit, focusedFeatureId, currentMapLevel, updateLiveRegion]);

  // Function to announce feature details and play appropriate sounds
  const announceFeature = useCallback((featureId: string, directionalSound: Direction | null = null) => {
    if (!audioInitialized) {
      console.warn('AudioEngine not initialized. Cannot announce feature.');
      return;
    }

    const feature = geoDataService.getFeatureById(featureId, currentMapLevel);
    if (!feature) {
      console.warn(`Feature ${featureId} not found for announcement.`);
      return;
    }

    // Always stop existing ambient sound before potentially playing a new one or directional sound
    audioEngine.stopOceanAmbient();

    if (directionalSound && !isMuted) {
      audioEngine.playDirectionalSound(directionalSound);
    }

    // Play specific ambient sound for the new feature type if not muted
    if (!isMuted) {
      switch (feature.boundary_type) {
        case 'Ocean':
        case 'Sea':
          audioEngine.playOceanAmbient();
          break;
        case 'River':
          audioEngine.playRiverSound();
          break;
        case 'MountainRange':
          audioEngine.playMountainSound();
          break;
        default:
          // No specific ambient for countries/states/districts on movement
          break;
      }
    }

    // Announce the feature name and its first description point
    updateLiveRegion(`${feature.name}, a ${feature.boundary_type}. ${feature.description_5pt[0] || ''}`);

  }, [audioInitialized, isMuted, currentMapLevel, updateLiveRegion]);


  useEffect(() => {
    const loadedFeatures = geoDataService.getFeatures(currentMapLevel);
    setFeatures(loadedFeatures);

    if (initialLoadRef.current) {
      initialLoadRef.current = false;
      // Initial welcome message handled by ensureAudioInitialized on first user interaction
    } else {
      // When map level changes, try to keep focus on a relevant feature
      // For now, if the focused feature ID is no longer valid at the new level, fallback
      const currentFocusedExists = geoDataService.getFeatureById(focusedFeatureId || '', currentMapLevel);
      if (!currentFocusedExists && loadedFeatures.length > 0) {
          // If the old focused ID doesn't exist at the new level, try to find a default or just pick the first
          const defaultFocusId = (currentMapLevel === MapLevel.WORLD) ? 'ATL_OCN_N' : loadedFeatures[0].feature_id;
          setFocusedFeatureId(defaultFocusId);
          // Announce after state update to ensure latest focusedFeatureId is used
          setTimeout(() => {
              if (defaultFocusId) announceFeature(defaultFocusId);
          }, 0);
      } else if (focusedFeatureId && currentFocusedExists) {
          // If existing focused feature is still valid, re-announce it
          announceFeature(focusedFeatureId);
      } else if (loadedFeatures.length > 0) {
        // Fallback to first feature if no specific focus
        setFocusedFeatureId(loadedFeatures[0].feature_id);
        setTimeout(() => {
          announceFeature(loadedFeatures[0].feature_id);
        }, 0);
      }

      updateLiveRegion(`Now viewing ${currentMapLevel}.`);
      if (!isMuted && audioInitialized) {
        audioEngine.playLevelChangeSound();
      }
    }
  }, [currentMapLevel, audioInitialized, isMuted, focusedFeatureId, announceFeature, updateLiveRegion]);

  // Handle ambient sounds based on focused feature *after* initial load and interaction
  useEffect(() => {
    if (userInteracted && audioInitialized && !isMuted && focusedFeatureId) {
      announceFeature(focusedFeatureId);
    } else if (isMuted) {
      audioEngine.stopOceanAmbient();
    }
  }, [focusedFeatureId, currentMapLevel, audioInitialized, isMuted, userInteracted, announceFeature]);


  // Handle keyboard navigation
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      // Only initialize audio once on first user interaction (key or click)
      ensureAudioInitialized();

      // If nothing is focused, try to focus the initial feature
      if (!focusedFeatureId) {
        const initialFeature = geoDataService.getFeatureById('ATL_OCN_N', currentMapLevel);
        if (initialFeature) {
          setFocusedFeatureId('ATL_OCN_N');
          setTimeout(() => { announceFeature('ATL_OCN_N'); }, 0);
        } else if (features.length > 0) {
          setFocusedFeatureId(features[0].feature_id);
          setTimeout(() => { announceFeature(features[0].feature_id); }, 0);
        }
        event.preventDefault(); // Prevent default if trying to navigate without focus
        return;
      }

      let nextFeatureId: string | null = null;
      let direction: Direction | null = null;

      switch (event.key) {
        case 'ArrowUp':
          direction = 'N';
          nextFeatureId = geoDataService.getNeighbor(focusedFeatureId, 'N', currentMapLevel);
          break;
        case 'ArrowDown':
          direction = 'S';
          nextFeatureId = geoDataService.getNeighbor(focusedFeatureId, 'S', currentMapLevel);
          break;
        case 'ArrowLeft':
          direction = 'W';
          nextFeatureId = geoDataService.getNeighbor(focusedFeatureId, 'W', currentMapLevel);
          break;
        case 'ArrowRight':
          direction = 'E';
          nextFeatureId = geoDataService.getNeighbor(focusedFeatureId, 'E', currentMapLevel);
          break;
        case 'Enter':
        case ' ': // Space key
          event.preventDefault(); // Prevent default scrolling
          handleZoomIn();
          break;
        case 'Backspace':
          event.preventDefault(); // Prevent default back navigation
          handleZoomOut();
          break;
        case 'd': // 'd' for description
          if (focusedFeatureId) {
            event.preventDefault(); // Prevent default behavior for 'd'
            handleSayDescription(focusedFeatureId);
          }
          break;
        case 'm': // 'm' for mute
          event.preventDefault(); // Prevent default behavior for 'm'
          toggleMute();
          break;
        default:
          return; // Do not prevent default for other keys
      }

      if (direction) {
        event.preventDefault(); // Prevent default browser actions for arrow keys
        if (nextFeatureId) {
          setFocusedFeatureId(nextFeatureId);
          // Announce after state update to ensure latest focusedFeatureId is used
          setTimeout(() => {
            const newFocusedElement = mapGridRef.current?.querySelector(`[data-feature-id="${nextFeatureId}"]`);
            if (newFocusedElement instanceof HTMLElement) {
              newFocusedElement.focus();
            }
            announceFeature(nextFeatureId, direction);
          }, 0);
        } else {
          // No navigable neighbor in that direction (true map edge/boundary like North Pole)
          updateLiveRegion('Beyond map edge. Cannot move further in this direction.');
          if (!isMuted) audioEngine.playBoundarySound();
          audioEngine.stopOceanAmbient(); // Stop ambient if hit boundary
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [focusedFeatureId, features, audioInitialized, isMuted, currentMapLevel, ensureAudioInitialized, announceFeature, updateLiveRegion]);

  const handleFeatureClick = (featureId: string) => {
    ensureAudioInitialized();
    setFocusedFeatureId(featureId);
    // Announcement handled by useEffect for focusedFeatureId change
    // Programmatically focus the clicked element for consistency
    setTimeout(() => {
      const clickedElement = mapGridRef.current?.querySelector(`[data-feature-id="${featureId}"]`);
      if (clickedElement instanceof HTMLElement) {
        clickedElement.focus();
      }
    }, 0);
  };

  const handleFeatureFocus = (featureId: string) => {
    ensureAudioInitialized();
    if (focusedFeatureId !== featureId) { // Only update if actual focus changed
      setFocusedFeatureId(featureId);
      // Announcement handled by useEffect for focusedFeatureId change
    }
  };

  const handleCellKeyDown = (e: React.KeyboardEvent<HTMLDivElement>, featureId: string) => {
    // This is primarily for 'Enter'/'Space' on a focused cell,
    // as arrow keys are handled by the global keydown listener.
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handleZoomIn();
    }
  };

  const handleZoomIn = () => {
    if (!audioInitialized) {
        ensureAudioInitialized();
        return;
    }
    if (!focusedFeatureId) {
      updateLiveRegion('No feature focused to zoom into.');
      return;
    }

    const currentFeature = geoDataService.getFeatureById(focusedFeatureId, currentMapLevel);
    if (!currentFeature) {
      updateLiveRegion('Focused feature not found.');
      return;
    }

    let newLevel: MapLevel | null = null;
    let newFocusId: string | null = null; // New focused ID for the next level

    switch (currentMapLevel) {
      case MapLevel.WORLD:
        if (currentFeature.feature_id === 'IN') {
          newLevel = MapLevel.INDIA_STATES;
          newFocusId = 'IN-GJ'; // Focus on a key state, e.g., Gujarat
        } else {
          updateLiveRegion(`No deeper level available for ${currentFeature.name}.`);
          return;
        }
        break;
      case MapLevel.INDIA_STATES:
        if (currentFeature.feature_id.startsWith('IN-GJ')) { // Check if it's a Gujarat state
          newLevel = MapLevel.INDIA_DISTRICTS;
          newFocusId = 'IN-GJ-AHM'; // Focus on Ahmedabad district
        } else {
          updateLiveRegion(`No deeper level available for ${currentFeature.name}.`);
          return;
        }
        break;
      case MapLevel.INDIA_DISTRICTS:
        updateLiveRegion(`No deeper level available for ${currentFeature.name}.`);
        return;
    }

    if (newLevel) {
      updateLiveRegion(`Zooming into ${currentFeature.name}.`);
      if (!isMuted) audioEngine.playLevelChangeSound();
      setCurrentMapLevel(newLevel);
      setFocusedFeatureId(newFocusId); // Set the new focused ID for the next level
    }
  };

  const handleZoomOut = () => {
    if (!audioInitialized) {
        ensureAudioInitialized();
        return;
    }
    let newLevel: MapLevel | null = null;
    let newFocusId: string | null = null;

    switch (currentMapLevel) {
      case MapLevel.INDIA_DISTRICTS:
        newLevel = MapLevel.INDIA_STATES;
        newFocusId = 'IN-GJ'; // Go back to Gujarat state
        break;
      case MapLevel.INDIA_STATES:
        newLevel = MapLevel.WORLD;
        newFocusId = 'IN'; // Go back to India country
        break;
      case MapLevel.WORLD:
        updateLiveRegion('Already at the highest map level (World).');
        return;
    }

    if (newLevel) {
      updateLiveRegion(`Zooming out to ${newLevel}.`);
      if (!isMuted) audioEngine.playLevelChangeSound();
      setCurrentMapLevel(newLevel);
      setFocusedFeatureId(newFocusId); // Set the new focused ID for the previous level
    }
  };

  const handleSayDescription = async (featureId: string) => {
    if (!audioInitialized) {
        ensureAudioInitialized();
        return;
    }
    const feature = geoDataService.getFeatureById(featureId, currentMapLevel);
    if (feature && !isLoadingSpeech && !isMuted) {
      setIsLoadingSpeech(true);
      // Stop any ambient sounds while speech is playing
      audioEngine.stopOceanAmbient();
      try {
        const description = feature.description_5pt.join(' ');
        updateLiveRegion(`Describing ${feature.name}. Please wait...`);
        await geminiService.generateAndPlaySpeech(description);
        updateLiveRegion(`Finished describing ${feature.name}.`);
      } catch (error) {
        console.error("Failed to generate or play speech:", error);
        updateLiveRegion("Failed to get description. Please try again.");
      } finally {
        setIsLoadingSpeech(false);
        // Resume ambient sound after speech if still on an ambient feature and not muted
        if (!isMuted) {
          announceFeature(featureId); // Re-trigger the announcement/ambient for the current feature
        }
      }
    } else if (isMuted) {
      updateLiveRegion("Audio is muted. Unmute to hear descriptions.");
    } else if (isLoadingSpeech) {
      updateLiveRegion("Speech is already loading. Please wait.");
    }
  };

  const toggleMute = () => {
    setIsMuted(prev => {
      const newState = !prev;
      if (newState) {
        audioEngine.stopAll();
        updateLiveRegion('Audio muted.');
      } else {
        // Fix: Use the public getter `isAudioInitialized` to check initialization status
        if (!audioEngine.isAudioInitialized()) {
            audioEngine.init();
            geminiService.initGenAI(); // Re-initialize GeminiService
            setUserInteracted(true);
            setAudioInitialized(true);
        }
        // Resume ambient sound logic if a feature is focused
        if (focusedFeatureId) {
          setTimeout(() => {
            announceFeature(focusedFeatureId);
          }, 100); // Small delay to allow audio context to be ready
        }
        updateLiveRegion('Audio unmuted.');
      }
      return newState;
    });
  };

  return (
    <div className="relative flex-grow flex items-center justify-center p-4">
      {/* Scrollable wrapper for WCAG 2.2 Reflow */}
      <div
        ref={mapGridRef}
        className="relative overflow-x-auto overflow-y-auto bg-gray-800 rounded-lg shadow-xl"
        style={{
          width: '100%',
          height: '100%',
          maxWidth: MAP_DISPLAY_WIDTH + 40,
          maxHeight: MAP_DISPLAY_HEIGHT + 40,
          outline: 'none',
        }}
        tabIndex={0}
        onFocus={ensureAudioInitialized}
        onClick={ensureAudioInitialized}
        aria-label={`Interactive map at ${currentMapLevel} level. Use arrow keys to navigate, Enter or Space to zoom in, Backspace to zoom out. Press 'D' for description, 'M' to mute/unmute. On smaller screens, the map may be scrollable.`}
        role="grid"
      >
        <div
          className="relative"
          style={{
            width: MAP_DISPLAY_WIDTH,
            height: MAP_DISPLAY_HEIGHT,
            // Visual background for the "ocean" area
            background: 'linear-gradient(180deg, rgba(30,58,138,1) 0%, rgba(17,24,39,1) 100%)',
          }}
        >
          {features.map((feature) => {
            const { top, left } = normalizeCoordinates(feature.centroid[0], feature.centroid[1]);

            return (
              <FeatureCell
                key={feature.feature_id}
                feature={feature}
                isFocused={focusedFeatureId === feature.feature_id}
                onClick={handleFeatureClick}
                onKeyDown={handleCellKeyDown}
                onFocus={handleFeatureFocus}
                style={{ top, left }}
              />
            );
          })}
        </div>
      </div>

      {/* Visually hidden region for screen reader announcements */}
      <div id="live-region" aria-live="polite" className="sr-only" ref={liveRegionRef}>
        {announcement}
      </div>

      {/* Controls */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex space-x-4 bg-gray-700 p-3 rounded-lg shadow-md z-30">
        <button
          onClick={handleZoomIn}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={!focusedFeatureId}
          aria-label="Zoom in to current feature"
        >
          Zoom In (Enter)
        </button>
        <button
          onClick={handleZoomOut}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={currentMapLevel === MapLevel.WORLD}
          aria-label="Zoom out to previous map level"
        >
          Zoom Out (Backspace)
        </button>
        <button
          onClick={() => focusedFeatureId && handleSayDescription(focusedFeatureId)}
          className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          disabled={!focusedFeatureId || isLoadingSpeech || isMuted}
          aria-label={isLoadingSpeech ? "Loading speech..." : `Hear description of ${geoDataService.getFeatureById(focusedFeatureId || '', currentMapLevel)?.name}`}
        >
          {isLoadingSpeech ? 'Loading...' : 'Say Description (D)'}
        </button>
        <button
          onClick={toggleMute}
          className={`px-4 py-2 ${isMuted ? 'bg-red-600 hover:bg-red-700' : 'bg-yellow-600 hover:bg-yellow-700'} text-white rounded-md transition-colors`}
          aria-label={isMuted ? "Unmute audio" : "Mute audio"}
        >
          {isMuted ? 'Unmute (M)' : 'Mute (M)'}
        </button>
      </div>

      <div className="absolute top-4 left-1/2 -translate-x-1/2 text-center bg-gray-700 p-2 rounded-lg shadow-md z-30">
        <p className="text-lg font-bold text-indigo-300">
          Current Level: {currentMapLevel}
        </p>
        <p className="text-md text-gray-200">
          Focused: {focusedFeatureId ? geoDataService.getFeatureById(focusedFeatureId, currentMapLevel)?.name : 'None'}
        </p>
      </div>
      <div className="sr-only absolute top-0 left-0 p-2 text-white bg-gray-900 rounded-b-lg">
        On smaller screens, the map may be scrollable horizontally and vertically.
      </div>
    </div>
  );
};

export default MapGrid;