// components/FeatureCell.tsx
import React from 'react';
import { Feature } from '../types';
import { CELL_WIDTH, CELL_HEIGHT } from '../constants';

interface FeatureCellProps {
  feature: Feature;
  isFocused: boolean;
  onClick: (featureId: string) => void;
  onKeyDown: (e: React.KeyboardEvent<HTMLDivElement>, featureId: string) => void;
  onFocus: (featureId: string) => void;
  style?: React.CSSProperties; // Add style prop for positioning
}

const FeatureCell: React.FC<FeatureCellProps> = ({
  feature,
  isFocused,
  onClick,
  onKeyDown,
  onFocus,
  style, // Destructure style prop
}) => {
  const handleClick = () => {
    onClick(feature.feature_id);
  };

  const handleFocus = () => {
    onFocus(feature.feature_id);
  };

  // Determine base styles for different boundary types
  const getBaseStyles = () => {
    switch (feature.boundary_type) {
      case 'Country':
      case 'State':
      case 'District':
        return 'bg-blue-800 border-blue-600 hover:bg-blue-700 hover:border-blue-500 text-gray-100';
      case 'Ocean':
      case 'Sea':
        return 'bg-blue-950 border-blue-800 hover:bg-blue-900 hover:border-blue-700 text-blue-200';
      case 'River':
        return 'bg-cyan-800 border-cyan-600 hover:bg-cyan-700 hover:border-cyan-500 text-cyan-200';
      case 'MountainRange':
        return 'bg-green-800 border-green-600 hover:bg-green-700 hover:border-green-500 text-green-200';
      default:
        return 'bg-gray-800 border-gray-600 hover:bg-gray-700 hover:border-gray-500 text-gray-100';
    }
  };

  return (
    <div
      role="gridcell"
      tabIndex={isFocused ? 0 : -1} // All features are now tabbable, focused one gets 0
      aria-label={`${feature.name}, a ${feature.boundary_type}. ${isFocused ? 'Currently focused.' : ''}`}
      onClick={handleClick}
      onKeyDown={(e) => onKeyDown(e, feature.feature_id)}
      onFocus={handleFocus}
      className={`
        absolute
        flex items-center justify-center
        border rounded-lg
        shadow-md
        transition-all duration-200 ease-in-out
        text-xs md:text-sm font-semibold text-center
        overflow-hidden
        cursor-pointer
        ${getBaseStyles()}
        ${isFocused
          ? 'bg-indigo-600 border-indigo-300 ring-2 ring-indigo-500 scale-110 z-20 text-white'
          : 'z-10'
        }
      `}
      style={{
        width: `${CELL_WIDTH}px`,
        height: `${CELL_HEIGHT}px`,
        ...style, // Apply passed style for positioning
      }}
      data-feature-id={feature.feature_id} // Custom data attribute for easier identification
    >
      <span className="p-1 leading-tight">{feature.name}</span>
      {isFocused && (
        <span className="sr-only">Press Enter or Space to zoom in, 'D' for description.</span>
      )}
    </div>
  );
};

export default FeatureCell;