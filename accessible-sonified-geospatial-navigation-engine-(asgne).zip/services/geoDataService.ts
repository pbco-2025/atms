// services/geoDataService.ts
import { Feature, MapLevel, Direction } from '../types';

// Helper for consistent boundary naming
const BOUNDARY = (name: string) => `${name} Boundary`;

// --- WORLD MAP FEATURES ---
// Centroids are Latitude, Longitude (Y, X) for mapping to screen coordinates.
// Neighbors are meticulously defined for global traversal, including wraps across the Pacific.
const worldFeatures: Feature[] = [
  // GLOBAL ORIENTATION Features
  {
    feature_id: 'NORTH_POLE', name: 'North Pole', centroid: [90, 0], boundary_type: 'Ocean', // Conceptual, as it's Arctic Ocean
    description_5pt: ['The very top of the globe.', 'Central ice of the Arctic Ocean.', 'Ringed by marginal seas.', 'Experiences 6 months of daylight and 6 months of darkness.', 'Home to diverse Arctic wildlife.'],
    neighbors: { N: null, S: 'ARC_OCN', E: 'NORTH_POLE', W: 'NORTH_POLE' },
  },
  {
    feature_id: 'SOUTH_POLE', name: 'South Pole', centroid: [-90, 0], boundary_type: 'Country', // Conceptual, as it's Antarctica
    description_5pt: ['Interior of Antarctica, a continuous icy landmass.', 'Surrounded by the Southern Ocean.', 'Experiences extreme cold and continuous darkness or daylight for months.', 'Site of scientific research stations.', 'Contains vast ice sheets.'],
    neighbors: { N: 'SOUTHERN_OCN', S: null, E: 'SOUTH_POLE', W: 'SOUTH_POLE' },
  },
  {
    feature_id: 'EQUATOR', name: 'Equator', centroid: [0, 0], boundary_type: 'River', // Conceptual line
    description_5pt: ['An invisible belt circling Earth halfway between the poles.', 'Cuts through South America, Africa, and islands of Southeast Asia.', 'Experiences consistent warm temperatures.', 'Longest parallel of latitude.', 'Receives direct sunlight for much of the year.'],
    neighbors: { N: 'AF_W', S: 'BR', E: 'ID', W: 'EC' }, // Conceptual links
  },
  {
    feature_id: 'PRIME_MERIDIAN', name: 'Prime Meridian (0°)', centroid: [0, 0], boundary_type: 'River', // Conceptual line
    description_5pt: ['Passes through western Europe (near Greenwich, UK).', 'Divides east/west longitudes.', 'The reference line for longitude.', 'Used to calculate time zones.', 'Historically significant for navigation.'],
    neighbors: { N: 'GB', S: 'AF_W', E: 'FR', W: 'ATL_OCN_N' }, // Conceptual links
  },

  // Band 1: Arctic and high northern latitudes (west to east)
  {
    feature_id: 'ARC_OCN', name: 'Arctic Ocean', centroid: [80, 0], boundary_type: 'Ocean',
    description_5pt: ['The central area — cold, icy sea.', 'Mostly sea ice in a ring of marginal seas.', 'Surrounds the North Pole.', 'Connects to Atlantic and Pacific Oceans.', 'Important for global climate regulation.'],
    neighbors: { N: 'NORTH_POLE', S: 'CA_ARC_ISL', E: 'ARC_OCN', W: 'ARC_OCN' }, // Self-loop for wrap
  },
  {
    feature_id: 'BER_SEA', name: 'Bering Sea', centroid: [58, 178], boundary_type: 'Sea',
    description_5pt: ['Northern edge of the Pacific, near Alaska and Russia.', 'Separated from the Pacific by the Aleutian Islands.', 'Rich fishing grounds.', 'Connects to the Arctic Ocean via the Bering Strait.', 'Experiences harsh weather conditions.'],
    neighbors: { N: 'CHU_SEA', S: 'PAC_OCN_W', E: 'US_AK', W: 'RU_FAR_EAST' },
  },
  {
    feature_id: 'US_AK', name: 'Alaska (USA)', centroid: [64, -152], boundary_type: 'Country',
    description_5pt: ['Large, irregular shape.', 'Major rivers flow south or west—the Yukon flows west then south into the Bering Sea.', 'Mountains (the Alaska Range) run across southern Alaska.', 'The largest U.S. state by area.', 'Known for its vast wilderness and wildlife.'],
    neighbors: { N: 'ARC_OCN', S: 'PAC_OCN_E', E: 'CA', W: 'BER_SEA' },
  },
  {
    feature_id: 'YUKON_RVR', name: 'Yukon River', centroid: [62, -145], boundary_type: 'River',
    description_5pt: ['Flows west then south into the Bering Sea.', 'Major river in Alaska and Canada.', 'Historically important during the Klondike Gold Rush.', 'Supports diverse fish populations.', 'Important for transport and hydropower.', 'Experiences significant seasonal flow changes.'],
    neighbors: { N: 'US_AK', S: 'BER_SEA', E: 'CA', W: 'BER_SEA' },
  },
  {
    feature_id: 'AK_RANGE', name: 'Alaska Range', centroid: [62, -150], boundary_type: 'MountainRange',
    description_5pt: ['Run across southern Alaska with raised ridges.', 'Home to Denali, North America\'s highest peak.', 'Formed by tectonic activity.', 'Known for its glaciers and rugged terrain.', 'Important for climbers and adventurers.'],
    neighbors: { N: 'US_AK', S: 'PAC_OCN_E', E: 'CA', W: 'US_AK' },
  },
  {
    feature_id: 'CA_ARC_ISL', name: 'Canadian Arctic Archipelago', centroid: [75, -95], boundary_type: 'Country',
    description_5pt: ['Many islands and channels north of Canada.', 'Includes Baffin Bay to the east of Baffin Island.', 'Mostly ice-covered.', 'Extremely remote and sparsely populated.', 'Important for Arctic research.'],
    neighbors: { N: 'ARC_OCN', S: 'CA', E: 'GL', W: 'BEAU_SEA' },
  },
  {
    feature_id: 'BAFFIN_BAY', name: 'Baffin Bay', centroid: [72, -60], boundary_type: 'Sea',
    description_5pt: ['East of Baffin Island, between Canada and Greenland.', 'Connects the Arctic Ocean with the Atlantic Ocean.', 'Important habitat for marine mammals.', 'Experiences heavy ice cover.', 'Named after explorer William Baffin.'],
    neighbors: { N: 'ARC_OCN', S: 'DAVIS_STRAIT', E: 'GL', W: 'CA_ARC_ISL' },
  },
  {
    feature_id: 'GL', name: 'Greenland', centroid: [72, -40], boundary_type: 'Country',
    description_5pt: ['Large rectangle-like island east of the Canadian islands.', 'Its coastline is deeply indented.', 'Most water is ice.', 'The world\'s largest island.', 'An autonomous territory of Denmark.'],
    neighbors: { N: 'ARC_OCN', S: 'ATL_OCN_N', E: 'NOR_SEA', W: 'BAFFIN_BAY' },
  },
  {
    feature_id: 'CHU_SEA', name: 'Chukchi Sea', centroid: [72, 170], boundary_type: 'Sea',
    description_5pt: ['Near Alaska and Russia, part of the Arctic Ocean.', 'Connects to the Bering Sea via the Bering Strait.', 'Historically important for whaling.', 'Covered by ice for much of the year.', 'Rich in biodiversity, including polar bears and walruses.'],
    neighbors: { N: 'ARC_OCN', S: 'BER_SEA', E: 'BEAU_SEA', W: 'RU_FAR_EAST' },
  },
  {
    feature_id: 'BEAU_SEA', name: 'Beaufort Sea', centroid: [72, -140], boundary_type: 'Sea',
    description_5pt: ['North of Canada, part of the Arctic Ocean.', 'Known for its oil and gas potential.', 'Home to bowhead whales.', 'Covered by sea ice most of the year.', 'Experiences strong currents.'],
    neighbors: { N: 'ARC_OCN', S: 'CA', E: 'CA_ARC_ISL', W: 'CHU_SEA' },
  },
  {
    feature_id: 'BARENTS_SEA', name: 'Barents Sea', centroid: [75, 40], boundary_type: 'Sea',
    description_5pt: ['North of Scandinavia and Russia, part of the Arctic Ocean.', 'One of the most productive marine areas.', 'Relatively shallow.', 'Ice-free for much of the year due to warm currents.', 'Important for fisheries and energy resources.'],
    neighbors: { N: 'ARC_OCN', S: 'NO', E: 'KARA_SEA', W: 'NOR_SEA' },
  },
  {
    feature_id: 'RU_SIBERIA', name: 'Siberia (Russia)', centroid: [60, 100], boundary_type: 'Country', // Representing Asian Russia
    description_5pt: ['Stretches across north Asia.', 'Huge, mostly flat with rivers that flow north into the Arctic (Ob, Yenisei, Lena).', 'Covers over 77% of Russia\'s land area.', 'Known for its extreme cold and vast wilderness.', 'Rich in natural resources, including minerals and timber.'],
    neighbors: { N: 'ARC_OCN', S: 'KZ', E: 'RU_FAR_EAST', W: 'RU' },
  },
  {
    feature_id: 'OB_RVR', name: 'Ob River', centroid: [67, 70], boundary_type: 'River',
    description_5pt: ['West Siberia, flows north to the Kara Sea.', 'One of the longest rivers in the world.', 'Its delta is rich in wetlands.', 'Important for transport and hydropower.', 'Freezes over for many months each year.'],
    neighbors: { N: 'KARA_SEA', S: 'RU_SIBERIA', E: 'YENISEI_RVR', W: 'RU_SIBERIA' },
  },
  {
    feature_id: 'YENISEI_RVR', name: 'Yenisei River', centroid: [67, 95], boundary_type: 'River',
    description_5pt: ['Central Siberia, flows north to the Kara/Laptev area.', 'Largest river system flowing to the Arctic Ocean.', 'Supports diverse ecosystems.', 'Important for hydropower and navigation.', 'Experiences dramatic seasonal changes.'],
    neighbors: { N: 'KARA_SEA', S: 'RU_SIBERIA', E: 'LENA_RVR', W: 'OB_RVR' },
  },
  {
    feature_id: 'LENA_RVR', name: 'Lena River', centroid: [67, 125], boundary_type: 'River',
    description_5pt: ['Eastern Siberia, flows north to the Laptev Sea.', 'One of the largest rivers in the world.', 'Its delta is a vast wetland.', 'Relatively untouched by human development.', 'Supports unique Arctic wildlife.'],
    neighbors: { N: 'LAPTEV_SEA', S: 'RU_SIBERIA', E: 'RU_FAR_EAST', W: 'YENISEI_RVR' },
  },
  {
    feature_id: 'SVALBARD', name: 'Svalbard (Norway)', centroid: [79, 20], boundary_type: 'Country',
    description_5pt: ['North of Norway.', 'An archipelago in the Arctic Ocean.', 'Known for its glaciers and polar bears.', 'Protected for its natural environment.', 'Global Seed Vault is located here.'],
    neighbors: { N: 'ARC_OCN', S: 'NOR_SEA', E: 'BARENTS_SEA', W: 'NOR_SEA' },
  },
  {
    feature_id: 'NOV_ZEMLYA', name: 'Novaya Zemlya (Russia)', centroid: [75, 55], boundary_type: 'Country',
    description_5pt: ['North of Russia, an archipelago in the Arctic Ocean.', 'Historically used for nuclear testing.', 'Home to diverse Arctic wildlife.', 'Covered by glaciers in the north.', 'Part of Arkhangelsk Oblast.'],
    neighbors: { N: 'ARC_OCN', S: 'RU', E: 'KARA_SEA', W: 'BARENTS_SEA' },
  },
  {
    feature_id: 'KARA_SEA', name: 'Kara Sea', centroid: [75, 75], boundary_type: 'Sea',
    description_5pt: ['Part of the Arctic Ocean, north of Siberia.', 'Bounded by Novaya Zemlya to the west.', 'Receives water from the Ob and Yenisei rivers.', 'Historically important for the Northern Sea Route.', 'Experiences heavy ice conditions.'],
    neighbors: { N: 'ARC_OCN', S: 'RU_SIBERIA', E: 'LAPTEV_SEA', W: 'BARENTS_SEA' },
  },
  {
    feature_id: 'LAPTEV_SEA', name: 'Laptev Sea', centroid: [75, 115], boundary_type: 'Sea',
    description_5pt: ['Part of the Arctic Ocean, north of Siberia.', 'Bounded by the Taymyr Peninsula and Severnaya Zemlya.', 'Receives water from the Lena River.', 'Known for its harsh climate and thick ice.', 'Named after Russian explorers Khariton and Dmitry Laptev.'],
    neighbors: { N: 'ARC_OCN', S: 'RU_SIBERIA', E: 'EAST_SIB_SEA', W: 'KARA_SEA' },
  },
  {
    feature_id: 'EAST_SIB_SEA', name: 'East Siberian Sea', centroid: [75, 150], boundary_type: 'Sea',
    description_5pt: ['Part of the Arctic Ocean, north of Siberia.', 'Bounded by the New Siberian Islands and Wrangel Island.', 'One of the least studied seas in the Arctic.', 'Experiences extreme temperatures and ice cover.', 'Important for polar bear habitat.'],
    neighbors: { N: 'ARC_OCN', S: 'RU_FAR_EAST', E: 'BER_SEA', W: 'LAPTEV_SEA' },
  },
  {
    feature_id: 'RU_FAR_EAST', name: 'Russian Far East', centroid: [55, 160], boundary_type: 'Country',
    description_5pt: ['Easternmost part of Russia, bordering the Pacific Ocean.', 'Mountainous and volcanic region.', 'Home to unique wildlife like Siberian tigers.', 'Strategically important.', 'Resource-rich area.'],
    neighbors: { N: 'EAST_SIB_SEA', S: 'JP', E: 'PAC_OCN_W', W: 'RU_SIBERIA' }, // JP = Japan
  },
  {
    feature_id: 'NOR_SEA', name: 'Norwegian Sea', centroid: [67, 0], boundary_type: 'Sea',
    description_5pt: ['North of Norway and west of Scandinavia.', 'Part of the North Atlantic Ocean.', 'Important fishing grounds.', 'Moderated by warm currents.', 'Deep sea basin.'],
    neighbors: { N: 'GL', S: 'NO', E: 'NO', W: 'ATL_OCN_N' },
  },

  // Band 2: High northern mid-latitudes (Boreal / temperate northern band; west to east)
  {
    feature_id: 'PAC_OCN_N_W', name: 'Northern Western Pacific Ocean', centroid: [45, 170], boundary_type: 'Ocean',
    description_5pt: ['Northern part of the Western Pacific, near Russia and Japan.', 'Known for its deep trenches.', 'Important for global weather patterns.', 'Rich in marine biodiversity.', 'Experiences seismic activity.'],
    neighbors: { N: 'BER_SEA', S: 'PAC_OCN_W', E: 'PAC_OCN_N_E', W: 'JP' }, // Wrap East
  },
  {
    feature_id: 'PAC_OCN_N_E', name: 'Northern Eastern Pacific Ocean', centroid: [45, -160], boundary_type: 'Ocean',
    description_5pt: ['Northern part of the Eastern Pacific, near Alaska and Canada.', 'Cold currents influence coastal climates.', 'Important migratory route for marine animals.', 'Vast and sparsely trafficked.', 'Experiences active weather systems.'],
    neighbors: { N: 'US_AK', S: 'PAC_OCN_E', E: 'CA', W: 'PAC_OCN_N_W' }, // Wrap West
  },
  {
    feature_id: 'CA', name: 'Canada', centroid: [55, -100], boundary_type: 'Country',
    description_5pt: ['North of the US.', 'Second largest country by area.', 'Known for maple syrup and politeness.', 'Capital is Ottawa.', 'Has vast wilderness.'],
    neighbors: { N: 'CA_ARC_ISL', S: 'US', E: 'ATL_OCN_N', W: 'PAC_OCN_N_E' },
  },
  {
    feature_id: 'US', name: 'United States', centroid: [40, -100], boundary_type: 'Country',
    description_5pt: ['A large country in North America.', 'Known for its diverse geography.', 'Has 50 states.', 'Capital is Washington D.C.', 'Population over 330 million.'],
    neighbors: { N: 'CA', S: 'MX', E: 'ATL_OCN_N', W: 'PAC_OCN_N_E' },
  },
  {
    feature_id: 'ROCKY_MTS', name: 'Rocky Mountains', centroid: [45, -110], boundary_type: 'MountainRange',
    description_5pt: ['Run north–south down western North America.', 'Raised ridges on the tactile map.', 'Source of many major rivers.', 'Home to diverse wildlife.', 'Important for tourism and recreation.'],
    neighbors: { N: 'CA', S: 'US', E: 'MISSOURI_RVR', W: 'PAC_OCN_N_E' },
  },
  {
    feature_id: 'MISSOURI_RVR', name: 'Missouri River', centroid: [40, -95], boundary_type: 'River',
    description_5pt: ['Long tributary to the Mississippi, flowing generally east/southeast.', 'Longest river in North America.', 'Historically important for westward expansion.', 'Major source of irrigation.', 'Often called "Big Muddy."'],
    neighbors: { N: 'US', S: 'MISSISSIPPI_RVR', E: 'US', W: 'ROCKY_MTS' },
  },
  {
    feature_id: 'COLUMBIA_RVR', name: 'Columbia River', centroid: [46, -120], boundary_type: 'River',
    description_5pt: ['Flows west from the Rockies to the Pacific.', 'Largest river in the Pacific Northwest.', 'Known for its salmon runs.', 'Major source of hydroelectric power.', 'Forms part of the border between Washington and Oregon.'],
    neighbors: { N: 'US', S: 'US', E: 'ROCKY_MTS', W: 'PAC_OCN_N_E' },
  },
  {
    feature_id: 'GREAT_LAKES', name: 'Great Lakes', centroid: [45, -85], boundary_type: 'Sea',
    description_5pt: ['System of large indentations on the U.S./Canada border.', 'Largest group of freshwater lakes on Earth.', 'Important for shipping and industry.', 'Home to diverse aquatic species.', 'Provides drinking water to millions.'],
    neighbors: { N: 'CA', S: 'US', E: 'ST_LAWRENCE_RVR', W: 'US' },
  },
  {
    feature_id: 'ST_LAWRENCE_RVR', name: 'St. Lawrence River', centroid: [47, -70], boundary_type: 'River',
    description_5pt: ['Flows northeast from the Great Lakes to the Atlantic.', 'Forms part of the border between Canada and the U.S.', 'Important for maritime transport.', 'Estuary is home to beluga whales.', 'Connects the Great Lakes to the Atlantic Ocean.'],
    neighbors: { N: 'CA', S: 'US', E: 'GULF_ST_LAWRENCE', W: 'GREAT_LAKES' },
  },
  {
    feature_id: 'GULF_ST_LAWRENCE', name: 'Gulf of St. Lawrence', centroid: [48, -63], boundary_type: 'Sea',
    description_5pt: ['Bay on the Atlantic coast of North America.', 'The outlet of the Great Lakes via the St. Lawrence River.', 'Important for fisheries.', 'Experiences cold winters with ice cover.', 'Surrounded by Canadian provinces.'],
    neighbors: { N: 'CA', S: 'CA', E: 'ATL_OCN_N', W: 'ST_LAWRENCE_RVR' },
  },
  {
    feature_id: 'ATL_OCN_N', name: 'North Atlantic Ocean', centroid: [45, -30], boundary_type: 'Ocean',
    description_5pt: ['Upper portion of the Atlantic Ocean.', 'Separates Europe/Africa from North America.', 'Important shipping route.', 'Home to diverse marine life.', 'Influences weather patterns of surrounding continents.'],
    neighbors: { N: 'GL', S: 'ATL_OCN_S', E: 'GB', W: 'CA' },
  },
  {
    feature_id: 'GB', name: 'United Kingdom', centroid: [55, -2], boundary_type: 'Country',
    description_5pt: ['British Isles (UK and Ireland).', 'An island nation in Europe.', 'Comprises England, Scotland, Wales, and Northern Ireland.', 'Known for its monarchy and history.', 'Capital is London.'],
    neighbors: { N: 'NORTH_SEA', S: 'ENG_CHANNEL', E: 'NORTH_SEA', W: 'IE' },
  },
  {
    feature_id: 'IE', name: 'Ireland', centroid: [53, -8], boundary_type: 'Country',
    description_5pt: ['British Isles (UK and Ireland).', 'An island nation west of Great Britain.', 'Known as the "Emerald Isle" for its lush green landscapes.', 'Capital is Dublin.', 'Rich Celtic culture.'],
    neighbors: { N: 'ATL_OCN_N', S: 'ATL_OCN_N', E: 'GB', W: 'ATL_OCN_N' },
  },
  {
    feature_id: 'FR', name: 'France', centroid: [47, 2], boundary_type: 'Country',
    description_5pt: ['A country in Western Europe.', 'Known for its art, fashion, and cuisine.', 'Capital is Paris.', 'Famous for the Eiffel Tower and wine.', 'Borders several countries.'],
    neighbors: { N: 'ENG_CHANNEL', S: 'PYRENEES_MTS', E: 'DE', W: 'ATL_OCN_N' },
  },
  {
    feature_id: 'ES', name: 'Spain', centroid: [40, -3], boundary_type: 'Country',
    description_5pt: ['To the southwest of France.', 'Located on the Iberian Peninsula.', 'Known for its vibrant culture, flamenco, and bullfighting.', 'Capital is Madrid.', 'Has a rich history and diverse regions.'],
    neighbors: { N: 'PYRENEES_MTS', S: 'MED_SEA', E: 'MED_SEA', W: 'PT' },
  },
  {
    feature_id: 'PT', name: 'Portugal', centroid: [39, -8], boundary_type: 'Country',
    description_5pt: ['On the Atlantic edge of Western Europe.', 'Known for its maritime history and Fado music.', 'Capital is Lisbon.', 'Famous for port wine and pastries.', 'Shares the Iberian Peninsula with Spain.'],
    neighbors: { N: 'ES', S: 'ATL_OCN_N', E: 'ES', W: 'ATL_OCN_N' },
  },
  {
    feature_id: 'PYRENEES_MTS', name: 'Pyrenees Mountains', centroid: [42, 1], boundary_type: 'MountainRange',
    description_5pt: ['Between Spain and France.', 'Run for about 491 km.', 'Natural border.', 'Home to unique flora and fauna.', 'Popular for hiking and skiing.'],
    neighbors: { N: 'FR', S: 'ES', E: 'FR', W: 'ES' },
  },
  {
    feature_id: 'ALPS_MTS', name: 'Alps Mountains', centroid: [46, 9], boundary_type: 'MountainRange',
    description_5pt: ['North of Italy.', 'The highest and most extensive mountain range system in Europe.', 'Major source of fresh water.', 'Important for tourism and winter sports.', 'Influence European climate patterns.'],
    neighbors: { N: 'DE', S: 'IT', E: 'AT', W: 'FR' }, // DE = Germany, AT = Austria
  },
  {
    feature_id: 'DE', name: 'Germany', centroid: [51, 10], boundary_type: 'Country',
    description_5pt: ['A country in Central Europe.', 'Known for its history, engineering, and culture.', 'Capital is Berlin.', 'Largest economy in Europe.', 'Famous for beer and Christmas markets.'],
    neighbors: { N: 'NORTH_SEA', S: 'ALPS_MTS', E: 'PL', W: 'FR' }, // PL = Poland
  },
  {
    feature_id: 'AT', name: 'Austria', centroid: [47, 14], boundary_type: 'Country',
    description_5pt: ['A landlocked country in Central Europe.', 'Known for its mountainous terrain and imperial history.', 'Capital is Vienna.', 'Famous for classical music and ski resorts.', 'Home to a portion of the Alps.'],
    neighbors: { N: 'DE', S: 'IT', E: 'HU', W: 'ALPS_MTS' }, // HU = Hungary
  },
  {
    feature_id: 'RHINE_RVR', name: 'Rhine River', centroid: [51, 6], boundary_type: 'River',
    description_5pt: ['Flows northwest into the North Sea.', 'One of Europe\'s major rivers.', 'Important for transport and trade.', 'Passes through several countries.', 'Known for its scenic valleys and castles.'],
    neighbors: { N: 'NORTH_SEA', S: 'DE', E: 'DE', W: 'FR' },
  },
  {
    feature_id: 'SEINE_RVR', name: 'Seine River', centroid: [49, 2], boundary_type: 'River',
    description_5pt: ['Flows northwest from France to the English Channel.', 'Passes through Paris.', 'Historically important for trade and transport.', 'Iconic landmark of France.', 'Subject of many famous paintings.'],
    neighbors: { N: 'ENG_CHANNEL', S: 'FR', E: 'FR', W: 'FR' },
  },
  {
    feature_id: 'NORTH_SEA', name: 'North Sea', centroid: [56, 5], boundary_type: 'Sea',
    description_5pt: ['East of the British Isles, west of Scandinavia.', 'Shallow, turbulent sea.', 'Important for oil and gas industry.', 'Major shipping route.', 'Rich fishing grounds.'],
    neighbors: { N: 'NO', S: 'ENG_CHANNEL', E: 'DK', W: 'GB' }, // DK = Denmark
  },
  {
    feature_id: 'ENG_CHANNEL', name: 'English Channel', centroid: [50, 0], boundary_type: 'Sea',
    description_5pt: ['Separates southern England from northern France.', 'Connects the North Sea to the Atlantic Ocean.', 'One of the busiest shipping lanes in the world.', 'Site of historical events.', 'Popular for crossing attempts.'],
    neighbors: { N: 'GB', S: 'FR', E: 'NORTH_SEA', W: 'ATL_OCN_N' },
  },
  {
    feature_id: 'NO', name: 'Norway', centroid: [61, 8], boundary_type: 'Country',
    description_5pt: ['Long, narrow coast faces the North Atlantic.', 'Has fjords (deep narrow inlets).', 'Known for its stunning natural beauty and Viking history.', 'Capital is Oslo.', 'Major oil and gas producer.'],
    neighbors: { N: 'BARENTS_SEA', S: 'SE', E: 'FI', W: 'NOR_SEA' },
  },
  {
    feature_id: 'SE', name: 'Sweden', centroid: [60, 15], boundary_type: 'Country',
    description_5pt: ['East of Norway, part of Scandinavia.', 'Known for its innovation and design.', 'Capital is Stockholm.', 'Has vast forests and lakes.', 'Constitutional monarchy.'],
    neighbors: { N: 'FI', S: 'BALTIC_SEA', E: 'BALTIC_SEA', W: 'NO' },
  },
  {
    feature_id: 'FI', name: 'Finland', centroid: [62, 26], boundary_type: 'Country',
    description_5pt: ['East of Sweden, part of Scandinavia.', 'Known as the "Land of a Thousand Lakes".', 'Capital is Helsinki.', 'Famous for its saunas and Moomins.', 'Shares a long border with Russia.'],
    neighbors: { N: 'ARC_OCN', S: 'BALTIC_SEA', E: 'RU', W: 'SE' },
  },
  {
    feature_id: 'BALTIC_SEA', name: 'Baltic Sea', centroid: [58, 20], boundary_type: 'Sea',
    description_5pt: ['East of Sweden and south of Finland.', 'Partially enclosed sea in Northern Europe.', 'Surrounded by nine countries.', 'Known for its low salinity.', 'Important for shipping and ecological studies.'],
    neighbors: { N: 'GULF_OF_BOTHNIA', S: 'DE', E: 'RU', W: 'SE' },
  },
  {
    feature_id: 'GULF_OF_BOTHNIA', name: 'Gulf of Bothnia', centroid: [64, 20], boundary_type: 'Sea',
    description_5pt: ['Between Sweden and Finland, part of the Baltic Sea.', 'Northernmost part of the Baltic Sea.', 'Experiences extensive ice cover in winter.', 'Important for fishing and shipping.', 'Unique brackish water ecosystem.'],
    neighbors: { N: 'FI', S: 'BALTIC_SEA', E: 'FI', W: 'SE' },
  },
  {
    feature_id: 'RU', name: 'European Russia', centroid: [55, 40], boundary_type: 'Country',
    description_5pt: ['Massive plain eastwards from Eastern Europe.', 'Most populous part of Russia.', 'Home to Moscow, the capital.', 'Vast forests and plains.', 'Culturally distinct from Asian Russia.'],
    neighbors: { N: 'BARENTS_SEA', S: 'BLACK_SEA', E: 'RU_SIBERIA', W: 'FI' },
  },
  {
    feature_id: 'VOLGA_RVR', name: 'Volga River', centroid: [50, 45], boundary_type: 'River',
    description_5pt: ['Europe\'s largest river, flows south into the Caspian Sea.', 'Longest river in Europe.', 'Historically important for trade and settlement.', 'Major source of irrigation and hydroelectric power.', 'Delta is a rich wetland ecosystem.'],
    neighbors: { N: 'RU', S: 'CASPIAN_SEA', E: 'KZ', W: 'RU' },
  },
  {
    feature_id: 'DON_RVR', name: 'Don River', centroid: [49, 39], boundary_type: 'River',
    description_5pt: ['Flows into the Sea of Azov.', 'Fifth longest river in Europe.', 'Important for navigation.', 'Historically significant.', 'Connects to the Volga via a canal.'],
    neighbors: { N: 'RU', S: 'SEA_AZOV', E: 'VOLGA_RVR', W: 'UA' }, // UA = Ukraine
  },
  {
    feature_id: 'SEA_AZOV', name: 'Sea of Azov', centroid: [46, 36], boundary_type: 'Sea',
    description_5pt: ['Smallest and shallowest sea in the world.', 'Connected to the Black Sea by the Strait of Kerch.', 'Receives water from the Don River.', 'Important for fishing and recreation.', 'Experiences freezing in winter.'],
    neighbors: { N: 'DON_RVR', S: 'BLACK_SEA', E: 'RU', W: 'UA' },
  },
  {
    feature_id: 'DANUBE_RVR', name: 'Danube River', centroid: [45, 20], boundary_type: 'River',
    description_5pt: ['Flows southeast from central Europe into the Black Sea.', 'Europe\'s second-longest river.', 'Passes through 10 countries.', 'Culturally and historically significant.', 'Major international waterway.'],
    neighbors: { N: 'AT', S: 'BG', E: 'BLACK_SEA', W: 'DE' }, // BG = Bulgaria
  },
  {
    feature_id: 'JP', name: 'Japan', centroid: [36, 138], boundary_type: 'Country',
    description_5pt: ['An island nation in East Asia.', 'Known for its unique culture, technology, and cuisine.', 'Capital is Tokyo.', 'Home to Mount Fuji.', 'Experiences frequent earthquakes.'],
    neighbors: { N: 'RU_FAR_EAST', S: 'EAST_CHINA_SEA', E: 'PAC_OCN_N_W', W: 'SK' }, // SK = South Korea
  },
  {
    feature_id: 'SK', name: 'South Korea', centroid: [36, 127], boundary_type: 'Country',
    description_5pt: ['A country in East Asia, forming the southern part of the Korean Peninsula.', 'Known for its vibrant pop culture, technology, and delicious food.', 'Capital is Seoul.', 'Shares a border with North Korea.', 'Rapid economic development.'],
    neighbors: { N: 'NK', S: 'EAST_CHINA_SEA', E: 'SEA_OF_JAPAN', W: 'YELLOW_SEA' }, // NK = North Korea
  },
  {
    feature_id: 'NK', name: 'North Korea', centroid: [40, 127], boundary_type: 'Country',
    description_5pt: ['A country in East Asia, forming the northern part of the Korean Peninsula.', 'Known for its isolated totalitarian regime.', 'Capital is Pyongyang.', 'Nuclear-armed state.', 'Shares a border with China and Russia.'],
    neighbors: { N: 'CN', S: 'SK', E: 'SEA_OF_JAPAN', W: 'YELLOW_SEA' },
  },
  {
    feature_id: 'SEA_OF_JAPAN', name: 'Sea of Japan', centroid: [40, 135], boundary_type: 'Sea',
    description_5pt: ['A marginal sea between Japan, North Korea, South Korea, and Russia.', 'Connects to the Pacific Ocean.', 'Known for its rich marine resources.', 'Experiences cold winters and warm summers.', 'Subject to naming disputes.'],
    neighbors: { N: 'RU_FAR_EAST', S: 'SK', E: 'JP', W: 'NK' },
  },

  // Band 3: Mid latitudes / Temperate (North America through Eurasia across central latitudes)
  {
    feature_id: 'MX', name: 'Mexico', centroid: [23, -102], boundary_type: 'Country',
    description_5pt: ['South of the US.', 'Known for its rich culture and history.', 'Capital is Mexico City.', 'Famous for tacos and mariachi music.', 'Has beautiful beaches.'],
    neighbors: { N: 'US', S: 'GTM', E: 'GULF_OF_MEXICO', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'MISSISSIPPI_RVR', name: 'Mississippi River', centroid: [35, -90], boundary_type: 'River',
    description_5pt: ['Flows from upper midwest south to the Gulf of Mexico.', 'Main tributary, the Missouri River, comes from the west.', 'One of the longest rivers in North America.', 'Historically important for trade and transport.', 'Forms a vast delta at its mouth.'],
    neighbors: { N: 'MISSOURI_RVR', S: 'GULF_OF_MEXICO', E: 'US', W: 'US' },
  },
  {
    feature_id: 'GULF_OF_MEXICO', name: 'Gulf of Mexico', centroid: [25, -90], boundary_type: 'Sea',
    description_5pt: ['Large bay on the Atlantic coast of North America.', 'Bordered by the US, Mexico, and Cuba.', 'Important for oil and gas production.', 'Supports diverse marine life.', 'Warm waters influence hurricane formation.'],
    neighbors: { N: 'US', S: 'MX', E: 'CU', W: 'MX' },
  },
  {
    feature_id: 'YUCATAN_PEN', name: 'Yucatan Peninsula', centroid: [20, -89], boundary_type: 'Country', // Represented as a feature
    description_5pt: ['Eastern side of Mexico, separating the Gulf of Mexico from the Caribbean Sea.', 'Known for its Mayan ruins and cenotes.', 'Popular tourist destination.', 'Flat limestone plain.', 'Home to diverse ecosystems.'],
    neighbors: { N: 'GULF_OF_MEXICO', S: 'BZ', E: 'CARIB_SEA', W: 'MX' }, // BZ = Belize
  },
  {
    feature_id: 'GTM', name: 'Guatemala', centroid: [15, -90], boundary_type: 'Country',
    description_5pt: ['A country in Central America.', 'Known for its ancient Mayan civilization.', 'Capital is Guatemala City.', 'Rich volcanic landscapes.', 'Diverse indigenous cultures.'],
    neighbors: { N: 'MX', S: 'ELS', E: 'HND', W: 'PAC_OCN_E' }, // ELS = El Salvador
  },
  {
    feature_id: 'HND', name: 'Honduras', centroid: [15, -86], boundary_type: 'Country',
    description_5pt: ['A country in Central America.', 'Known for its rich natural resources and Mayan ruins.', 'Capital is Tegucigalpa.', 'Caribbean and Pacific coastlines.', 'Biodiversity hotspots.'],
    neighbors: { N: 'GTM', S: 'NIC', E: 'CARIB_SEA', W: 'ELS' },
  },
  {
    feature_id: 'NIC', name: 'Nicaragua', centroid: [13, -85], boundary_type: 'Country',
    description_5pt: ['A country in Central America.', 'Largest country in Central America.', 'Known for its lakes, volcanoes, and beaches.', 'Capital is Managua.', 'Rich biodiversity and cultural heritage.'],
    neighbors: { N: 'HND', S: 'CRI', E: 'CARIB_SEA', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'CRI', name: 'Costa Rica', centroid: [10, -84], boundary_type: 'Country',
    description_5pt: ['A country in Central America.', 'Known for its rainforests and eco-tourism.', 'Capital is San José.', 'High biodiversity.', 'No standing army since 1949.'],
    neighbors: { N: 'NIC', S: 'PA', E: 'CARIB_SEA', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'PA', name: 'Panama', centroid: [9, -80], boundary_type: 'Country',
    description_5pt: ['A country in Central America.', 'Connects North and South America.', 'Known for the Panama Canal.', 'Capital is Panama City.', 'Tropical climate and diverse ecosystems.'],
    neighbors: { N: 'CRI', S: 'COL', E: 'CARIB_SEA', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'CARIB_SEA', name: 'Caribbean Sea', centroid: [15, -75], boundary_type: 'Sea',
    description_5pt: ['Sits to the east of Central America with many islands.', 'Part of the Atlantic Ocean.', 'Known for its warm waters, coral reefs, and hurricanes.', 'Major tourist destination.', 'Important shipping routes.'],
    neighbors: { N: 'CU', S: 'COL', E: 'ATL_OCN_S', W: 'PA' },
  },
  {
    feature_id: 'CU', name: 'Cuba', centroid: [22, -80], boundary_type: 'Country',
    description_5pt: ['Largest island in the Caribbean.', 'Known for its rich history, music, and cigars.', 'Capital is Havana.', 'Socialist state.', 'Famous for classic cars.'],
    neighbors: { N: 'GULF_OF_MEXICO', S: 'CARIB_SEA', E: 'HT', W: 'YUCATAN_PEN' },
  },
  {
    feature_id: 'HT', name: 'Haiti', centroid: [19, -72], boundary_type: 'Country',
    description_5pt: ['Shares Hispaniola island with Dominican Republic.', 'First independent nation of Latin America and the Caribbean.', 'Capital is Port-au-Prince.', 'French Creole culture.', 'Prone to natural disasters.'],
    neighbors: { N: 'CARIB_SEA', S: 'CARIB_SEA', E: 'DO', W: 'CU' },
  },
  {
    feature_id: 'DO', name: 'Dominican Republic', centroid: [19, -70], boundary_type: 'Country',
    description_5pt: ['Shares Hispaniola island with Haiti.', 'Known for its beautiful beaches and merengue music.', 'Capital is Santo Domingo.', 'Popular tourist destination.', 'Shares highest peak in Caribbean.'],
    neighbors: { N: 'CARIB_SEA', S: 'CARIB_SEA', E: 'PR', W: 'HT' },
  },
  {
    feature_id: 'PR', name: 'Puerto Rico (USA)', centroid: [18, -66], boundary_type: 'Country',
    description_5pt: ['An island territory of the United States.', 'Known for its vibrant culture and El Yunque rainforest.', 'Capital is San Juan.', 'Spanish and English are official languages.', 'Famous for salsa music.'],
    neighbors: { N: 'ATL_OCN_S', S: 'CARIB_SEA', E: 'ATL_OCN_S', W: 'DO' },
  },
  {
    feature_id: 'JM', name: 'Jamaica', centroid: [18, -77], boundary_type: 'Country',
    description_5pt: ['An island nation in the Caribbean.', 'Known for reggae music and Bob Marley.', 'Capital is Kingston.', 'Tropical climate.', 'Popular for its beaches and resorts.'],
    neighbors: { N: 'CARIB_SEA', S: 'CARIB_SEA', E: 'HT', W: 'CU' },
  },
  {
    feature_id: 'COL', name: 'Colombia', centroid: [4, -72], boundary_type: 'Country',
    description_5pt: ['Northwestern South America.', 'Only country in South America with both Atlantic and Pacific coastlines.', 'Known for coffee and emeralds.', 'Capital is Bogotá.', 'Diverse ecosystems and biodiversity.'],
    neighbors: { N: 'PA', S: 'EC', E: 'VE', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'VE', name: 'Venezuela', centroid: [8, -66], boundary_type: 'Country',
    description_5pt: ['Northern South America, on the Caribbean coast.', 'Known for its oil reserves and Angel Falls.', 'Capital is Caracas.', 'Home to diverse landscapes.', 'Spanish is the official language.'],
    neighbors: { N: 'CARIB_SEA', S: 'BR', E: 'GY', W: 'COL' }, // GY = Guyana
  },
  {
    feature_id: 'BR', name: 'Brazil', centroid: [-10, -55], boundary_type: 'Country',
    description_5pt: ['Huge Atlantic coast, largest country in South America.', 'Known for the Amazon Rainforest and Carnival.', 'Capital is Brasília.', 'Portuguese-speaking.', 'Fifth largest country in the world.'],
    neighbors: { N: 'VE', S: 'AR', E: 'ATL_OCN_S', W: 'AMAZON_RVR' },
  },
  {
    feature_id: 'ATL_OCN_S', name: 'South Atlantic Ocean', centroid: [-10, -20], boundary_type: 'Ocean',
    description_5pt: ['Lower portion of the Atlantic Ocean.', 'Separates South America from Africa.', 'Important for global ocean circulation.', 'Home to unique marine species.', 'Influences climate patterns in both continents.'],
    neighbors: { N: 'ATL_OCN_N', S: 'SOUTHERN_OCN', E: 'AF_W', W: 'BR' },
  },
  {
    feature_id: 'MA', name: 'Morocco', centroid: [32, -6], boundary_type: 'Country',
    description_5pt: ['North Africa, on the Atlantic-Mediterranean corridor.', 'Known for its vibrant markets and ancient cities.', 'Capital is Rabat.', 'Rich Berber and Arab culture.', 'Gateway to Africa.'],
    neighbors: { N: 'MED_SEA', S: 'WSA', E: 'DZ', W: 'ATL_OCN_N' }, // WSA = Western Sahara
  },
  {
    feature_id: 'DZ', name: 'Algeria', centroid: [28, 3], boundary_type: 'Country',
    description_5pt: ['North Africa, on the Atlantic-Mediterranean corridor.', 'Largest country in Africa by area.', 'Dominated by the Sahara Desert.', 'Capital is Algiers.', 'Rich historical and cultural heritage.'],
    neighbors: { N: 'MED_SEA', S: 'ML', E: 'TN', W: 'MA' }, // ML = Mali
  },
  {
    feature_id: 'TN', name: 'Tunisia', centroid: [34, 9], boundary_type: 'Country',
    description_5pt: ['North Africa, on the Atlantic-Mediterranean corridor.', 'Smallest country in North Africa.', 'Known for its ancient Carthage ruins.', 'Capital is Tunis.', 'Popular for coastal tourism.'],
    neighbors: { N: 'MED_SEA', S: 'DZ', E: 'LY', W: 'DZ' },
  },
  {
    feature_id: 'LY', name: 'Libya', centroid: [28, 17], boundary_type: 'Country',
    description_5pt: ['North Africa.', 'Dominated by the Sahara Desert.', 'Known for its ancient Roman and Greek ruins.', 'Capital is Tripoli.', 'Rich in oil resources.'],
    neighbors: { N: 'MED_SEA', S: 'TD', E: 'EG', W: 'TN' }, // TD = Chad
  },
  {
    feature_id: 'EG', name: 'Egypt', centroid: [27, 30], boundary_type: 'Country',
    description_5pt: ['North Africa.', 'Known for its ancient civilization, pyramids, and pharaohs.', 'Capital is Cairo.', 'Located on the Nile River.', 'Connects to the Middle East.'],
    neighbors: { N: 'MED_SEA', S: 'SD', E: 'RED_SEA', W: 'LY' }, // SD = Sudan
  },
  {
    feature_id: 'MED_SEA', name: 'Mediterranean Sea', centroid: [38, 18], boundary_type: 'Sea',
    description_5pt: ['Long inland sea interrupted by narrow straits.', 'Connects to the Atlantic via the Strait of Gibraltar.', 'Surrounded by Europe, Africa, and Asia.', 'Historically important for trade and culture.', 'Warm, saline waters.'],
    neighbors: { N: 'IT', S: 'DZ', E: 'GR', W: 'MA' }, // GR = Greece
  },
  {
    feature_id: 'STR_GIBRALTAR', name: 'Strait of Gibraltar', centroid: [36, -5], boundary_type: 'Sea',
    description_5pt: ['Connects the Mediterranean Sea to the Atlantic Ocean.', 'Narrow strait between Europe and Africa.', 'Important shipping lane.', 'Known for its strong currents.', 'Views of the Rock of Gibraltar.'],
    neighbors: { N: 'ES', S: 'MA', E: 'MED_SEA', W: 'ATL_OCN_N' },
  },
  {
    feature_id: 'NILE_RVR', name: 'Nile River', centroid: [20, 32], boundary_type: 'River',
    description_5pt: ['Flows northward from the highlands of East Africa through Sudan and Egypt into the Mediterranean.', 'The longest river in Africa.', 'Historically crucial for ancient Egyptian civilization.', 'Supports vast agricultural areas.', 'Known for its unique ecosystem.'],
    neighbors: { N: 'EG', S: 'SD', E: 'RED_SEA', W: 'LY' },
  },
  {
    feature_id: 'IT', name: 'Italy', centroid: [42, 12], boundary_type: 'Country',
    description_5pt: ['Boot-shaped peninsula in Southern Europe.', 'Known for its art, history, and cuisine.', 'Capital is Rome.', 'Home to ancient Roman Empire.', 'Diverse landscapes from mountains to coastlines.'],
    neighbors: { N: 'ALPS_MTS', S: 'MED_SEA', E: 'ADRIATIC_SEA', W: 'FR' },
  },
  {
    feature_id: 'ADRIATIC_SEA', name: 'Adriatic Sea', centroid: [43, 15], boundary_type: 'Sea',
    description_5pt: ['East of Italy, part of the Mediterranean.', 'Separates the Italian Peninsula from the Balkan Peninsula.', 'Known for its beautiful coastline.', 'Important for tourism and fishing.', 'Relatively shallow.'],
    neighbors: { N: 'IT', S: 'MED_SEA', E: 'HR', W: 'IT' }, // HR = Croatia
  },
  {
    feature_id: 'AEGEAN_SEA', name: 'Aegean Sea', centroid: [39, 25], boundary_type: 'Sea',
    description_5pt: ['East of Greece, part of the Mediterranean.', 'Numerous islands.', 'Historically significant.', 'Important for shipping.', 'Known for its unique blue waters.'],
    neighbors: { N: 'GR', S: 'MED_SEA', E: 'TR', W: 'GR' },
  },
  {
    feature_id: 'BLACK_SEA', name: 'Black Sea', centroid: [43, 35], boundary_type: 'Sea',
    description_5pt: ['Northeast of Turkey, landlocked sea.', 'Connects to the Mediterranean via the Bosporus and Dardanelles.', 'Receives water from major rivers like the Danube.', 'Known for its anoxic deep waters.', 'Historically important for trade and cultural exchange.'],
    neighbors: { N: 'UA', S: 'TR', E: 'GE', W: 'BG' }, // GE = Georgia
  },
  {
    feature_id: 'TR', name: 'Turkey', centroid: [39, 35], boundary_type: 'Country',
    description_5pt: ['Transcontinental country bridging Europe and Asia.', 'Known for its rich history and diverse culture.', 'Capital is Ankara.', 'Home to ancient civilizations.', 'Connects the Black Sea to the Mediterranean.'],
    neighbors: { N: 'BLACK_SEA', S: 'SY', E: 'ARM', W: 'GR' }, // SY = Syria, ARM = Armenia
  },
  {
    feature_id: 'CAUCASUS_MTS', name: 'Caucasus Mountains', centroid: [42, 45], boundary_type: 'MountainRange',
    description_5pt: ['Lie between the Black and Caspian Seas.', 'Form a natural boundary between Europe and Asia.', 'Home to diverse ethnic groups.', 'Known for its rugged beauty and high peaks.', 'Important for biodiversity.'],
    neighbors: { N: 'RU', S: 'TR', E: 'AZ', W: 'GE' }, // AZ = Azerbaijan
  },
  {
    feature_id: 'KZ', name: 'Kazakhstan', centroid: [48, 68], boundary_type: 'Country',
    description_5pt: ['East of the Caspian and Ural mountains.', 'Largest landlocked country in the world.', 'Vast steppes stretching toward China.', 'Known for its oil and gas reserves.', 'Cosmodrome in Baikonur.'],
    neighbors: { N: 'RU_SIBERIA', S: 'UZ', E: 'CN', W: 'CASPIAN_SEA' }, // UZ = Uzbekistan
  },
  {
    feature_id: 'CASPIAN_SEA', name: 'Caspian Sea', centroid: [42, 51], boundary_type: 'Sea',
    description_5pt: ['Largest enclosed inland body of water on Earth.', 'Borders Russia, Kazakhstan, Turkmenistan, Iran, and Azerbaijan.', 'Important for oil and gas reserves.', 'Home to unique marine species like the Caspian seal.', 'Its status as a lake or sea is debated.'],
    neighbors: { N: 'VOLGA_RVR', S: 'IR', E: 'KZ', W: 'AZ' }, // IR = Iran
  },
  {
    feature_id: 'CN', name: 'China', centroid: [35.8617, 104.1954], boundary_type: 'Country',
    description_5pt: ["World's most populous country with over 1.4 billion people", "Third-largest country by area (9.6 million km²) after Russia and Canada", "Home to Himalayas, Tibetan Plateau, Yellow and Yangtze rivers", "Ancient civilization with Great Wall, Forbidden City, Terracotta Army", "Major economic powerhouse and manufacturing hub, Belt and Road Initiative"],
    neighbors: { N: 'MN', S: 'IN', E: 'YELLOW_SEA', W: 'KZ' }, // MN = Mongolia
  },
  {
    feature_id: 'YELLOW_SEA', name: 'Yellow Sea', centroid: [36, 122], boundary_type: 'Sea',
    description_5pt: ['Between mainland China and the Korean Peninsula.', 'Known for its shallow waters and yellow silt.', 'Important for fishing and shipping.', 'Experiences cold winters and warm summers.', 'Historically significant.'],
    neighbors: { N: 'CN', S: 'EAST_CHINA_SEA', E: 'SK', W: 'CN' },
  },
  {
    feature_id: 'EAST_CHINA_SEA', name: 'East China Sea', centroid: [28, 125], boundary_type: 'Sea',
    description_5pt: ['Marginal sea east of China, part of the Pacific Ocean.', 'Borders China, Japan, and South Korea.', 'Known for its strong currents.', 'Important for shipping and fishing.', 'Subject to territorial disputes.'],
    neighbors: { N: 'YELLOW_SEA', S: 'TAIWAN_STRAIT', E: 'JP', W: 'CN' },
  },
  {
    feature_id: 'TAIWAN_STRAIT', name: 'Taiwan Strait', centroid: [24, 119], boundary_type: 'Sea',
    description_5pt: ['Separates mainland China from the island of Taiwan.', 'Important international waterway.', 'Known for its strategic significance.', 'Experiences strong winds and currents.', 'Home to diverse marine life.'],
    neighbors: { N: 'EAST_CHINA_SEA', S: 'SOUTH_CHINA_SEA', E: 'TW', W: 'CN' }, // TW = Taiwan
  },
  {
    feature_id: 'TAIWAN', name: 'Taiwan', centroid: [23, 121], boundary_type: 'Country',
    description_5pt: ['Island nation off the coast of mainland China.', 'Known for its bustling cities, vibrant night markets, and mountainous terrain.', 'Capital is Taipei.', 'Technological powerhouse.', 'Disputed political status.'],
    neighbors: { N: 'EAST_CHINA_SEA', S: 'SOUTH_CHINA_SEA', E: 'PAC_OCN_W', W: 'TAIWAN_STRAIT' },
  },
  {
    feature_id: 'YANGTZE_RVR', name: 'Yangtze River', centroid: [30, 112], boundary_type: 'River',
    description_5pt: ['Flows eastward to the East China Sea.', 'Longest river in Asia, third longest in the world.', 'Crucial for China\'s economy and agriculture.', 'Home to diverse ecosystems.', 'Historically significant.'],
    neighbors: { N: 'CN', S: 'CN', E: 'EAST_CHINA_SEA', W: 'CN' },
  },
  {
    feature_id: 'YELLOW_RVR', name: 'Yellow River (Huang He)', centroid: [35, 110], boundary_type: 'River',
    description_5pt: ['Flows eastward into Yellow Sea.', 'Second longest river in China.', 'Known as "China\'s Sorrow" due to historical floods.', 'Cradle of Chinese civilization.', 'Carries large amounts of silt.'],
    neighbors: { N: 'CN', S: 'CN', E: 'YELLOW_SEA', W: 'CN' },
  },
  {
    feature_id: 'HIMALAYA', name: 'Himalayan Mountains', centroid: [30, 85], boundary_type: 'MountainRange',
    description_5pt: ['The highest mountain range in the world.', 'Includes Mount Everest.', 'A natural barrier between India and China.', 'Source of many major rivers.', 'Significant religious importance.'],
    neighbors: { N: 'CN', S: 'IN', E: 'BT', W: 'PK' }, // BT = Bhutan
  },
  {
    feature_id: 'TIBETAN_PLATEAU', name: 'Tibetan Plateau', centroid: [35, 90], boundary_type: 'MountainRange',
    description_5pt: ['High plateau in Central Asia, part of the Himalayas.', 'Often called the "Roof of the World".', 'Source of many major rivers in Asia.', 'Experiences extreme cold and high altitude.', 'Culturally significant.'],
    neighbors: { N: 'CN', S: 'HIMALAYA', E: 'CN', W: 'IN' },
  },

  // Band 4: Equatorial / Tropical belt (crosses mid-latitudes around the equator; west to east)
  {
    feature_id: 'PAC_OCN_E', name: 'Eastern Pacific Ocean', centroid: [10, -140], boundary_type: 'Ocean',
    description_5pt: ['Vast expanse of water in the eastern part of the Pacific.', 'Borders North and South America.', 'Often colder than the Western Pacific due to currents.', 'Important for El Niño and La Niña phenomena.', 'Major fishing grounds.'],
    neighbors: { N: 'PAC_OCN_N_E', S: 'PAC_OCN_S', E: 'COL', W: 'PAC_OCN_W' },
  },
  {
    feature_id: 'PAC_OCN_W', name: 'Western Pacific Ocean', centroid: [10, 170], boundary_type: 'Ocean',
    description_5pt: ['Vast expanse of water in the western part of the Pacific.', 'Borders Asia and Australia.', 'Contains numerous island nations.', 'Known for its diverse marine life and coral reefs.', 'Deepest parts of the ocean are found here.'],
    neighbors: { N: 'PAC_OCN_N_W', S: 'PAC_OCN_S', E: 'PAC_OCN_E', W: 'ID' },
  },
  {
    feature_id: 'EC', name: 'Ecuador', centroid: [-1, -78], boundary_type: 'Country',
    description_5pt: ['West coast of South America.', 'Named for its location on the equator.', 'Known for the Galapagos Islands and Andean landscape.', 'Capital is Quito.', 'High biodiversity.'],
    neighbors: { N: 'COL', S: 'PE', E: 'AMAZON_RVR', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'PE', name: 'Peru', centroid: [-9, -76], boundary_type: 'Country',
    description_5pt: ['West coast of South America.', 'Known for Machu Picchu and ancient Inca civilization.', 'Capital is Lima.', 'Diverse geography from coastal desert to Andean mountains.', 'Rich in cultural heritage.'],
    neighbors: { N: 'EC', S: 'CL', E: 'BR', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'CL', name: 'Chile', centroid: [-30, -71], boundary_type: 'Country',
    description_5pt: ['Long western spine along the Andes.', 'Narrow country stretching along the southwest coast of South America.', 'Known for its diverse landscapes, from deserts to glaciers.', 'Capital is Santiago.', 'Major producer of copper.'],
    neighbors: { N: 'PE', S: 'SOUTHERN_OCN', E: 'AR', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'ANDES_MTS', name: 'Andes Mountains', centroid: [-15, -70], boundary_type: 'MountainRange',
    description_5pt: ['Run as a long raised ridge along the entire western edge of South America, north→south.', 'Longest continental mountain range in the world.', 'Home to diverse ecosystems and unique species.', 'Influences regional climate patterns.', 'Site of ancient civilizations.'],
    neighbors: { N: 'COL', S: 'CL', E: 'AMAZON_RVR', W: 'PAC_OCN_E' },
  },
  {
    feature_id: 'AMAZON_RVR', name: 'Amazon River', centroid: [-3, -60], boundary_type: 'River',
    description_5pt: ['Enormous Amazon River system, a very wide groove.', 'Collects many tributaries (Madeira, Negro, Tapajós) and flows eastward across northern Brazil into the Atlantic.', 'The largest river by discharge volume in the world.', 'Surrounded by the Amazon Rainforest.', 'Home to incredible biodiversity.'],
    neighbors: { N: 'BR', S: 'BR', E: 'ATL_OCN_S', W: 'ANDES_MTS' },
  },
  {
    feature_id: 'MADEIRA_RVR', name: 'Madeira River', centroid: [-8, -65], boundary_type: 'River',
    description_5pt: ['Major tributary of the Amazon River.', 'Flows through Bolivia and Brazil.', 'Important for transport and agriculture.', 'Rich in biodiversity.', 'One of the longest tributaries in the world.'],
    neighbors: { N: 'AMAZON_RVR', S: 'BO', E: 'AMAZON_RVR', W: 'PE' }, // BO = Bolivia
  },
  {
    feature_id: 'NEGRO_RVR', name: 'Negro River', centroid: [-2, -62], boundary_type: 'River',
    description_5pt: ['Major tributary of the Amazon River.', 'Known for its blackwater color.', 'Flows through Colombia, Venezuela, and Brazil.', 'Rich in fish species.', 'Largest blackwater river in the world.'],
    neighbors: { N: 'AMAZON_RVR', S: 'AMAZON_RVR', E: 'AMAZON_RVR', W: 'AMAZON_RVR' },
  },
  {
    feature_id: 'TAPAJOS_RVR', name: 'Tapajós River', centroid: [-5, -55], boundary_type: 'River',
    description_5pt: ['Major tributary of the Amazon River.', 'Flows through Brazil.', 'Known for its clear waters.', 'Important for regional transport and fishing.', 'Biodiverse ecosystem.'],
    neighbors: { N: 'AMAZON_RVR', S: 'BR', E: 'BR', W: 'AMAZON_RVR' },
  },
  {
    feature_id: 'AF_W', name: 'West Africa', centroid: [10, 0], boundary_type: 'Country',
    description_5pt: ['Senegal, Guinea, Sierra Leone, Liberia, Ivory Coast, Ghana, Togo, Benin, Nigeria.', 'Home to diverse cultures and languages.', 'Known for its vibrant music and art.', 'Rich in natural resources.', 'Experiences tropical climates.'],
    neighbors: { N: 'SAHARA', S: 'GULF_GUINEA', E: 'AF_CEN', W: 'ATL_OCN_S' }, // SAHARA = Sahara Desert
  },
  {
    feature_id: 'SAHARA', name: 'Sahara Desert', centroid: [20, 10], boundary_type: 'Country', // Represented as a feature
    description_5pt: ['The largest hot desert in the world.', 'Dominates northern Africa.', 'Known for its vast sand dunes and extreme temperatures.', 'Sparse vegetation.', 'Historically important for trade routes.'],
    neighbors: { N: 'DZ', S: 'AF_W', E: 'LY', W: 'ML' },
  },
  {
    feature_id: 'NIGER_RVR', name: 'Niger River', centroid: [12, 5], boundary_type: 'River',
    description_5pt: ['Initially flows northeast into the Sahara then curves southeast into the Gulf of Guinea (a boomerang shape).', 'Third-longest river in Africa.', 'Historically important for trade and empires.', 'Forms a vast inner delta.', 'Crucial for agriculture.'],
    neighbors: { N: 'SAHARA', S: 'GULF_GUINEA', E: 'NG', W: 'ML' }, // NG = Nigeria
  },
  {
    feature_id: 'VOLTA_RVR', name: 'Volta River', centroid: [8, 0], boundary_type: 'River',
    description_5pt: ['Volta systems in Ghana flow south to the Gulf of Guinea.', 'Important for hydropower and irrigation.', 'Forms Lake Volta, one of the largest artificial lakes.', 'Supports diverse aquatic life.', 'Critical for Ghanaian economy.'],
    neighbors: { N: 'GH', S: 'GULF_GUINEA', E: 'TG', W: 'CI' }, // GH = Ghana, TG = Togo, CI = Ivory Coast
  },
  {
    feature_id: 'GULF_GUINEA', name: 'Gulf of Guinea', centroid: [0, 5], boundary_type: 'Sea',
    description_5pt: ['On the west coast of Africa.', 'Part of the Atlantic Ocean.', 'Receives water from the Niger and Volta rivers.', 'Known for its warm waters and oil reserves.', 'Historically important for trade.'],
    neighbors: { N: 'NG', S: 'ATL_OCN_S', E: 'CM', W: 'GH' }, // CM = Cameroon
  },
  {
    feature_id: 'AF_CEN', name: 'Central Africa', centroid: [0, 20], boundary_type: 'Country',
    description_5pt: ['Includes Congo Basin, East Africa’s highlands.', 'Home to vast rainforests and savannas.', 'Rich in biodiversity and natural resources.', 'Diverse ethnic groups.', 'Experiences tropical climates.'],
    neighbors: { N: 'SAHARA', S: 'AF_S', E: 'AF_E', W: 'AF_W' }, // AF_S = Southern Africa, AF_E = East Africa
  },
  {
    feature_id: 'CONGO_RVR', name: 'Congo River', centroid: [-2, 18], boundary_type: 'River',
    description_5pt: ['Massive groove flowing westwards around the equator into the Atlantic.', 'Drains a huge rainforest.', 'Second-longest river in Africa by length, largest by discharge volume.', 'Forms a deep canyon under the Atlantic.', 'Important for hydropower and transport.'],
    neighbors: { N: 'CD', S: 'AO', E: 'CD', W: 'ATL_OCN_S' }, // CD = Dem. Rep. of Congo, AO = Angola
  },
  {
    feature_id: 'GREAT_RIFT_VALLEY', name: 'Great Rift Valley', centroid: [5, 36], boundary_type: 'MountainRange',
    description_5pt: ['Long structural depression with lakes in East Africa.', 'Stretches for thousands of kilometers.', 'Known for its unique geology and fossil discoveries.', 'Home to diverse ecosystems and wildlife.', 'Site of active volcanism.'],
    neighbors: { N: 'ET', S: 'TZ', E: 'KE', W: 'UG' }, // ET = Ethiopia, TZ = Tanzania, KE = Kenya, UG = Uganda
  },
  {
    feature_id: 'ZAMBEZI_RVR', name: 'Zambezi River', centroid: [-17, 28], boundary_type: 'River',
    description_5pt: ['In southern central Africa, flows east to the Indian Ocean (with Victoria Falls on it).', 'Fourth-longest river in Africa.', 'Forms a vast delta at its mouth.', 'Important for hydropower.', 'Home to diverse wildlife.'],
    neighbors: { N: 'ZM', S: 'ZW', E: 'MOZ_CHANNEL', W: 'AO' }, // ZM = Zambia, ZW = Zimbabwe
  },
  {
    feature_id: 'IO_OCN', name: 'Indian Ocean', centroid: [-20, 70], boundary_type: 'Ocean',
    description_5pt: ['Third largest of the world\'s oceanic divisions.', 'Borders Asia, Africa, and Australia.', 'Warmest ocean in the world.', 'Important trade routes.', 'Monsoon climate influence.'],
    neighbors: { N: 'ARABIAN_SEA', S: 'SOUTHERN_OCN', E: 'TIMOR_SEA', W: 'MOZ_CHANNEL' },
  },
  {
    feature_id: 'IN', name: 'India', centroid: [20.5937, 78.9629], boundary_type: 'Country',
    description_5pt: ['Located in South Asia, seventh-largest country by area (3.287 million km²)', 'World\'s most populous democracy with over 1.4 billion people (2023)', 'Home to the Himalayas in the north and extensive coastline along Arabian Sea and Bay of Bengal', 'Federal union of 28 states and 8 union territories with diverse languages and cultures', 'Major geographic features include Ganges River, Thar Desert, Western and Eastern Ghats'],
    neighbors: { N: 'HIMALAYA', S: 'IO_OCN', E: 'BD', W: 'PK' },
  },
  {
    feature_id: 'LK', name: 'Sri Lanka', centroid: [7, 81], boundary_type: 'Country',
    description_5pt: ['Island nation south of India in the Indian Ocean.', 'Known for its rich cultural heritage and beautiful beaches.', 'Capital is Sri Jayawardenepura Kotte.', 'Important for tea production.', 'Diverse ecosystems.'],
    neighbors: { N: 'IN', S: 'IO_OCN', E: 'BAY_BENGAL', W: 'IO_OCN' },
  },
  {
    feature_id: 'GANGES_RVR', name: 'Ganges River', centroid: [25, 80], boundary_type: 'River',
    description_5pt: ['Flows east across northern India into the Bay of Bengal.', 'Sacred river in Hinduism.', 'Supports millions of people.', 'Rich delta region.', 'One of the most densely populated river basins.'],
    neighbors: { N: 'HIMALAYA', S: 'IN', E: 'BD', W: 'IN' },
  },
  {
    feature_id: 'INDUS_RVR', name: 'Indus River', centroid: [30, 70], boundary_type: 'River',
    description_5pt: ['Flows south along Pakistan into the Arabian Sea.', 'Longest river in Pakistan.', 'Historically significant for ancient civilizations.', 'Crucial for agriculture.', 'Forms a large delta.'],
    neighbors: { N: 'PK', S: 'ARABIAN_SEA', E: 'IN', W: 'PK' },
  },
  {
    feature_id: 'BRAHMAPUTRA_RVR', name: 'Brahmaputra River', centroid: [26, 91], boundary_type: 'River',
    description_5pt: ['In eastern India/Bangladesh, joins the Ganges delta into the Bay of Bengal.', 'Major trans-boundary river in Asia.', 'Known for its braided channels.', 'Prone to flooding.', 'Important for navigation.'],
    neighbors: { N: 'CN', S: 'BD', E: 'MM', W: 'IN' }, // MM = Myanmar
  },
  {
    feature_id: 'BAY_BENGAL', name: 'Bay of Bengal', centroid: [15, 88], boundary_type: 'Sea',
    description_5pt: ['Northeastern part of the Indian Ocean.', 'Borders India, Bangladesh, Myanmar, and Sri Lanka.', 'Receives water from major rivers.', 'Prone to tropical cyclones.', 'Rich in marine resources.'],
    neighbors: { N: 'BD', S: 'IO_OCN', E: 'MM', W: 'IN' },
  },
  {
    feature_id: 'MM', name: 'Myanmar', centroid: [20, 96], boundary_type: 'Country',
    description_5pt: ['Southeast Asia, borders India and China.', 'Known for its golden pagodas and rich cultural heritage.', 'Capital is Naypyidaw.', 'Diverse ethnic groups.', 'Shares borders with five countries.'],
    neighbors: { N: 'CN', S: 'ANDAMAN_SEA', E: 'TH', W: 'BD' }, // TH = Thailand
  },
  {
    feature_id: 'TH', name: 'Thailand', centroid: [15, 101], boundary_type: 'Country',
    description_5pt: ['Southeast Asia.', 'Known for its tropical beaches, ancient ruins, and ornate temples.', 'Capital is Bangkok.', 'Popular tourist destination.', 'Never colonized by a European power.'],
    neighbors: { N: 'LA', S: 'MAL', E: 'KH', W: 'MM' }, // LA = Laos, MAL = Malaysia, KH = Cambodia
  },
  {
    feature_id: 'KH', name: 'Cambodia', centroid: [13, 104], boundary_type: 'Country',
    description_5pt: ['Southeast Asia.', 'Known for Angkor Wat, ancient temples.', 'Capital is Phnom Penh.', 'Rich Khmer culture.', 'Borders Thailand, Laos, and Vietnam.'],
    neighbors: { N: 'LA', S: 'GULF_THAILAND', E: 'VN', W: 'TH' }, // VN = Vietnam
  },
  {
    feature_id: 'LA', name: 'Laos', centroid: [18, 103], boundary_type: 'Country',
    description_5pt: ['Southeast Asia, landlocked.', 'Known for its mountainous terrain, Buddhist monasteries, and French colonial architecture.', 'Capital is Vientiane.', 'The only landlocked country in Southeast Asia.', 'Rich cultural heritage.'],
    neighbors: { N: 'CN', S: 'KH', E: 'VN', W: 'TH' },
  },
  {
    feature_id: 'VN', name: 'Vietnam', centroid: [16, 107], boundary_type: 'Country',
    description_5pt: ['Southeast Asia, long coastline.', 'Known for its stunning natural beauty, bustling cities, and rich history.', 'Capital is Hanoi.', 'Famous for pho and strong coffee.', 'Communist one-party state.'],
    neighbors: { N: 'CN', S: 'SOUTH_CHINA_SEA', E: 'SOUTH_CHINA_SEA', W: 'LA' },
  },
  {
    feature_id: 'MEKONG_RVR', name: 'Mekong River', centroid: [15, 105], boundary_type: 'River',
    description_5pt: ['Flows south from China through Southeast Asia into the South China Sea.', 'Twelfth longest river in the world.', 'Lifeline for millions of people.', 'Rich biodiversity.', 'Experiences significant damming.'],
    neighbors: { N: 'CN', S: 'SOUTH_CHINA_SEA', E: 'VN', W: 'TH' },
  },
  {
    feature_id: 'ID', name: 'Indonesia', centroid: [-5, 120], boundary_type: 'Country',
    description_5pt: ['Chain of islands (Sumatra, Java, Borneo, Sulawesi to New Guinea) straddling the equator.', 'Largest archipelago in the world.', 'Known for its diverse cultures and active volcanoes.', 'Capital is Jakarta.', 'Mega-biodiverse country.'],
    neighbors: { N: 'SOUTH_CHINA_SEA', S: 'TIMOR_SEA', E: 'PNG', W: 'IO_OCN' }, // PNG = Papua New Guinea
  },
  {
    feature_id: 'MAL', name: 'Malaysia', centroid: [4, 102], boundary_type: 'Country',
    description_5pt: ['Southeast Asia, part on Malay Peninsula and Borneo.', 'Known for its vibrant culture, rainforests, and diverse cuisine.', 'Capital is Kuala Lumpur.', 'Tropical climate.', 'Ethnically and religiously diverse.'],
    neighbors: { N: 'TH', S: 'ID', E: 'SOUTH_CHINA_SEA', W: 'ANDAMAN_SEA' },
  },
  {
    feature_id: 'PH', name: 'Philippines', centroid: [12, 122], boundary_type: 'Country',
    description_5pt: ['Archipelago north of Indonesia.', 'Comprises over 7,000 islands.', 'Known for its beautiful beaches and rich marine life.', 'Capital is Manila.', 'Spanish colonial heritage.'],
    neighbors: { N: 'SOUTH_CHINA_SEA', S: 'ID', E: 'PAC_OCN_W', W: 'SOUTH_CHINA_SEA' },
  },
  {
    feature_id: 'SOUTH_CHINA_SEA', name: 'South China Sea', centroid: [10, 110], boundary_type: 'Sea',
    description_5pt: ['Shallow sea within Southeast Asia.', 'Borders China, Vietnam, Philippines, Malaysia, and Indonesia.', 'Strategically important shipping lane.', 'Rich fishing grounds.', 'Subject of territorial disputes.'],
    neighbors: { N: 'CN', S: 'ID', E: 'PH', W: 'VN' },
  },
  {
    feature_id: 'JAVA_SEA', name: 'Java Sea', centroid: [-5, 110], boundary_type: 'Sea',
    description_5pt: ['Shallow sea within Indonesia.', 'Between Java, Sumatra, Borneo, and Sulawesi.', 'Important shipping route.', 'Rich in marine biodiversity.', 'Site of historical naval battles.'],
    neighbors: { N: 'ID', S: 'ID', E: 'ID', W: 'ID' }, // Simplified
  },
  {
    feature_id: 'ANDAMAN_SEA', name: 'Andaman Sea', centroid: [10, 95], boundary_type: 'Sea',
    description_5pt: ['Shallow sea within Southeast Asia.', 'Part of the Indian Ocean, southeast of the Bay of Bengal.', 'Known for its beautiful islands and coral reefs.', 'Popular for diving and snorkeling.', 'Experiences monsoons.'],
    neighbors: { N: 'MM', S: 'MAL', E: 'TH', W: 'BAY_BENGAL' },
  },

  // Band 5: Southern temperate / mid-southern latitudes (west to east)
  {
    feature_id: 'ARAFURA_SEA', name: 'Arafura Sea', centroid: [-9, 135], boundary_type: 'Sea',
    description_5pt: ['Moving east from Indonesia you encounter the Arafura Sea.', 'Part of the Pacific Ocean, between Australia and New Guinea.', 'Shallow, tropical sea.', 'Important for fisheries.', 'Experiences monsoons.'],
    neighbors: { N: 'PNG', S: 'AU', E: 'PAC_OCN_S', W: 'TIMOR_SEA' },
  },
  {
    feature_id: 'TIMOR_SEA', name: 'Timor Sea', centroid: [-10, 128], boundary_type: 'Sea',
    description_5pt: ['Between Indonesia and Australia.', 'Part of the Indian Ocean.', 'Known for its oil and gas reserves.', 'Experiences tropical cyclones.', 'Historically important for trade routes.'],
    neighbors: { N: 'ID', S: 'AU', E: 'ARAFURA_SEA', W: 'IO_OCN' },
  },
  {
    feature_id: 'AU', name: 'Australia', centroid: [-25, 135], boundary_type: 'Country',
    description_5pt: ['Large, roughly circular landmass with the Great Dividing Range along the east coast.', 'Central desert interior (flat).', 'Largest country in Oceania.', 'Known for its unique wildlife (kangaroos, koalas).', 'Only country that is also a continent.'],
    neighbors: { N: 'TIMOR_SEA', S: 'SOUTHERN_OCN', E: 'PAC_OCN_S', W: 'IO_OCN' },
  },
  {
    feature_id: 'GREAT_DIV_RANGE', name: 'Great Dividing Range', centroid: [-28, 150], boundary_type: 'MountainRange',
    description_5pt: ['Runs along the east coast of Australia.', 'Australia\'s most substantial mountain range.', 'Source of many rivers.', 'Important for biodiversity.', 'Influences regional climate patterns.'],
    neighbors: { N: 'AU', S: 'AU_TS', E: 'PAC_OCN_S', W: 'AU' }, // AU_TS = Tasmania
  },
  {
    feature_id: 'MURRAY_DARLING_RVR', name: 'Murray–Darling River System', centroid: [-34, 142], boundary_type: 'River',
    description_5pt: ['Flows southeast toward the Southern Ocean from central Australia.', 'Australia\'s longest river system.', 'Crucial for agriculture.', 'Ecologically significant.', 'Experiences droughts and floods.'],
    neighbors: { N: 'AU', S: 'SOUTHERN_OCN', E: 'AU', W: 'AU' },
  },
  {
    feature_id: 'AU_TS', name: 'Tasmania (Australia)', centroid: [-42, 147], boundary_type: 'Country',
    description_5pt: ['Smaller island to the south of Australia.', 'Known for its rugged wilderness and unique wildlife.', 'Capital is Hobart.', 'Separated from mainland Australia by Bass Strait.', 'Cool temperate climate.'],
    neighbors: { N: 'AU', S: 'SOUTHERN_OCN', E: 'PAC_OCN_S', W: 'SOUTHERN_OCN' },
  },
  {
    feature_id: 'AF_S', name: 'Southern Africa', centroid: [-25, 25], boundary_type: 'Country',
    description_5pt: ['South Africa at the southern tip; Mozambique and Madagascar to the east.', 'Known for its diverse landscapes, wildlife, and cultures.', 'Rich in mineral resources.', 'Experiences varied climates.', 'Historically significant.'],
    neighbors: { N: 'AF_CEN', S: 'SOUTHERN_OCN', E: 'MOZ_CHANNEL', W: 'ATL_OCN_S' },
  },
  {
    feature_id: 'ZA', name: 'South Africa', centroid: [-30, 24], boundary_type: 'Country',
    description_5pt: ['Southern tip of Africa.', 'Known for its diverse cultures, wildlife, and natural beauty.', 'Capital cities include Pretoria, Cape Town, and Bloemfontein.', 'Rich in mineral resources.', 'Famous for Nelson Mandela.'],
    neighbors: { N: 'BW', S: 'SOUTHERN_OCN', E: 'IO_OCN', W: 'ATL_OCN_S' }, // BW = Botswana
  },
  {
    feature_id: 'MZ', name: 'Mozambique', centroid: [-18, 35], boundary_type: 'Country',
    description_5pt: ['East of Southern Africa, on the Indian Ocean coast.', 'Known for its pristine beaches and coral reefs.', 'Capital is Maputo.', 'Portuguese colonial heritage.', 'Rich biodiversity.'],
    neighbors: { N: 'TZ', S: 'ZA', E: 'MOZ_CHANNEL', W: 'ZW' }, // TZ = Tanzania, ZW = Zimbabwe
  },
  {
    feature_id: 'MG', name: 'Madagascar', centroid: [-20, 47], boundary_type: 'Country',
    description_5pt: ['Large elongated island off Africa’s southeast coast.', 'Fourth largest island in the world.', 'Known for its unique lemurs and biodiversity.', 'French and Malagasy are official languages.', 'Experiences tropical climates.'],
    neighbors: { N: 'IO_OCN', S: 'IO_OCN', E: 'IO_OCN', W: 'MOZ_CHANNEL' },
  },
  {
    feature_id: 'MOZ_CHANNEL', name: 'Mozambique Channel', centroid: [-18, 42], boundary_type: 'Sea',
    description_5pt: ['Between Mozambique and Madagascar.', 'Part of the Indian Ocean.', 'Important shipping route.', 'Known for its strong currents.', 'Rich in marine life.'],
    neighbors: { N: 'MZ', S: 'IO_OCN', E: 'MG', W: 'MZ' },
  },
  {
    feature_id: 'LIMPOPO_RVR', name: 'Limpopo River', centroid: [-24, 30], boundary_type: 'River',
    description_5pt: ['Flows east toward the Indian Ocean from interior southern Africa.', 'Second-largest river in Africa that drains into the Indian Ocean.', 'Forms a natural border between several countries.', 'Known for its wildlife and baobab trees.', 'Experiences seasonal flooding.'],
    neighbors: { N: 'ZW', S: 'ZA', E: 'MZ', W: 'BW' },
  },
  {
    feature_id: 'ORANGE_RVR', name: 'Orange River', centroid: [-29, 19], boundary_type: 'River',
    description_5pt: ['Flows west to the Atlantic from interior southern Africa.', 'Longest river in South Africa.', 'Important for irrigation and diamond mining.', 'Forms part of the border with Namibia.', 'Known for its dramatic waterfalls.'],
    neighbors: { N: 'NA', S: 'ZA', E: 'ZA', W: 'ATL_OCN_S' }, // NA = Namibia
  },
  {
    feature_id: 'AR', name: 'Argentina', centroid: [-35, -65], boundary_type: 'Country',
    description_5pt: ['Broader eastern South America.', 'Second largest country in South America.', 'Known for tango, beef, and Patagonia.', 'Capital is Buenos Aires.', 'Diverse landscapes from mountains to plains.'],
    neighbors: { N: 'BR', S: 'TIERRA_DEL_FUEGO', E: 'ATL_OCN_S', W: 'CL' },
  },
  {
    feature_id: 'PARANA_RVR', name: 'Paraná River', centroid: [-28, -58], boundary_type: 'River',
    description_5pt: ['In eastern South America, flows into the Rio de la Plata estuary.', 'Second longest river in South America.', 'Important for navigation and hydropower.', 'Forms part of the border between several countries.', 'Known for its wetlands and wildlife.'],
    neighbors: { N: 'BR', S: 'RIO_DE_LA_PLATA', E: 'UY', W: 'AR' }, // UY = Uruguay
  },
  {
    feature_id: 'URUGUAY_RVR', name: 'Uruguay River', centroid: [-33, -58], boundary_type: 'River',
    description_5pt: ['In eastern South America, flows into the Rio de la Plata estuary.', 'Forms part of the border between Argentina, Brazil, and Uruguay.', 'Important for navigation.', 'Known for its waterfalls.', 'Supports diverse ecosystems.'],
    neighbors: { N: 'BR', S: 'RIO_DE_LA_PLATA', E: 'UY', W: 'AR' },
  },
  {
    feature_id: 'RIO_DE_LA_PLATA', name: 'Rio de la Plata Estuary', centroid: [-35, -57], boundary_type: 'Sea',
    description_5pt: ['Estuary opening into the Atlantic between Uruguay and Argentina.', 'Often called the "River Plate".', 'Important for shipping.', 'Experiences strong tidal currents.', 'Rich in marine life.'],
    neighbors: { N: 'AR', S: 'ATL_OCN_S', E: 'ATL_OCN_S', W: 'AR' },
  },
  {
    feature_id: 'TIERRA_DEL_FUEGO', name: 'Tierra del Fuego', centroid: [-54, -68], boundary_type: 'Country',
    description_5pt: ['Southern tip of South America.', 'Separated from the mainland by the Strait of Magellan.', 'Shared by Argentina and Chile.', 'Known for its rugged beauty and cold climate.', 'Home to unique wildlife.'],
    neighbors: { N: 'AR', S: 'SOUTHERN_OCN', E: 'ATL_OCN_S', W: 'STR_MAGELLAN' },
  },
  {
    feature_id: 'STR_MAGELLAN', name: 'Strait of Magellan', centroid: [-53, -71], boundary_type: 'Sea',
    description_5pt: ['Separates Tierra del Fuego from mainland South America.', 'Natural navigable passage between the Atlantic and Pacific Oceans.', 'Historically important for exploration.', 'Known for its strong winds and currents.', 'Rugged and scenic environment.'],
    neighbors: { N: 'CL', S: 'TIERRA_DEL_FUEGO', E: 'ATL_OCN_S', W: 'PAC_OCN_S' },
  },
  {
    feature_id: 'PAC_OCN_S', name: 'Southern Pacific Ocean', centroid: [-30, -170], boundary_type: 'Ocean',
    description_5pt: ['Southern portion of the Pacific Ocean.', 'Connects to the Southern Ocean.', 'Vast and deep.', 'Known for its remote islands.', 'Influences global weather patterns.'],
    neighbors: { N: 'PAC_OCN_E', S: 'SOUTHERN_OCN', E: 'CL', W: 'AU' },
  },

  // Band 6: Antarctica and South Pole
  {
    feature_id: 'SOUTHERN_OCN', name: 'Southern Ocean', centroid: [-60, 0], boundary_type: 'Ocean',
    description_5pt: ['The seas around Antarctica.', 'Currents are strong with circum-Antarctic flow.', 'Encircles Antarctica.', 'Home to unique cold-water marine life.', 'Important for global climate regulation.'],
    neighbors: { N: 'PAC_OCN_S', S: 'SOUTH_POLE', E: 'SOUTHERN_OCN', W: 'SOUTHERN_OCN' }, // Self-loop for wrap
  },
  {
    feature_id: 'AQ', name: 'Antarctica', centroid: [-80, 0], boundary_type: 'Country',
    description_5pt: ['Huge white continent surrounding the South Pole.', 'Coastlines marked by ice shelves and bays (e.g., Ross Sea, Weddell Sea).', 'Thick ring or circle at the bottom with many indentations.', 'Mostly glaciers that flow from the interior to the sea.', 'Coldest, driest, and highest continent.'],
    neighbors: { N: 'SOUTHERN_OCN', S: 'SOUTH_POLE', E: 'AQ', W: 'AQ' }, // Self-loop for wrap
  },

  // --- India States (Example Zoom Level) ---
  {
    feature_id: 'IN-GJ',
    name: 'Gujarat State',
    centroid: [22.2587, 71.1924],
    description_5pt: ['Westernmost state of India.', 'Known for its vibrant culture and garba dance.', 'Birthplace of Mahatma Gandhi.', 'Has a long coastline.', 'Famous for its unique cuisine.'],
    neighbors: { N: 'IN-RJ', S: 'ARABIAN_SEA_IN', E: 'IN-MP', W: 'ARABIAN_SEA_IN' },
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-RJ',
    name: 'Rajasthan State',
    centroid: [27.0238, 74.2179],
    description_5pt: ['Largest state in India by area.', 'Home to the Thar Desert.', 'Known for its historical forts and palaces.', 'Capital is Jaipur.', 'Rich folk music and dance.'],
    neighbors: { N: 'PK', S: 'IN-GJ', E: 'IN-MP', W: 'PK' },
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-MP',
    name: 'Madhya Pradesh State',
    centroid: [22.9734, 78.6569],
    description_5pt: ['Central state of India.', 'Known as the "Heart of India".', 'Has numerous national parks.', 'Capital is Bhopal.', 'Rich in tribal culture.'],
    neighbors: { N: 'IN-RJ', S: 'IN-MH', E: 'IN-CT', W: 'IN-GJ' },
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-MH',
    name: 'Maharashtra State',
    centroid: [19.7515, 75.7139],
    description_5pt: ['Western Indian state.', 'Home to Mumbai, the financial capital.', 'Known for Bollywood.', 'Deccan Plateau region.', 'Rich Maratha history.'],
    neighbors: { N: 'IN-MP', S: 'IN-GA', E: 'IN-CT', W: 'ARABIAN_SEA_IN' }, // IN-GA = Goa
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-CT',
    name: 'Chhattisgarh State',
    centroid: [21.2787, 81.8661],
    description_5pt: ['East-central state of India.', 'Known for its rich cultural heritage and natural diversity.', 'Dense forests and waterfalls.', 'Capital is Raipur.', 'High tribal population.'],
    neighbors: { N: 'IN-MP', S: 'IN-OR', E: 'IN-OR', W: 'IN-MP' }, // IN-OR = Odisha
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-GA',
    name: 'Goa State',
    centroid: [15.2993, 74.1240],
    description_5pt: ['Smallest state in India.', 'Known for its beautiful beaches and vibrant nightlife.', 'Portuguese heritage.', 'Popular tourist destination.', 'Rich biodiversity.'],
    neighbors: { N: 'IN-MH', S: 'IN-KA', E: 'IN-KA', W: 'ARABIAN_SEA_IN' }, // IN-KA = Karnataka
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-KA',
    name: 'Karnataka State',
    centroid: [14.4898, 76.6710],
    description_5pt: ['Southern Indian state.', 'Home to Bangalore, the "Silicon Valley of India".', 'Known for its ancient ruins and national parks.', 'Capital is Bengaluru.', 'Rich cultural heritage.'],
    neighbors: { N: 'IN-MH', S: 'IN-KL', E: 'IN-AP', W: 'ARABIAN_SEA_IN' }, // IN-KL = Kerala, IN-AP = Andhra Pradesh
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-KL',
    name: 'Kerala State',
    centroid: [10.8505, 76.2711],
    description_5pt: ['Southwestern Indian state.', 'Known for its backwaters, beaches, and Ayurveda.', 'High literacy rate.', 'Capital is Thiruvananthapuram.', 'Spice rich.'],
    neighbors: { N: 'IN-KA', S: 'IO_OCN_IN', E: 'IN-TN', W: 'ARABIAN_SEA_IN' }, // IN-TN = Tamil Nadu
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-TN',
    name: 'Tamil Nadu State',
    centroid: [11.1271, 78.6569],
    description_5pt: ['Southernmost state of India.', 'Known for its ancient temples and Dravidian culture.', 'Capital is Chennai.', 'Home to various classical arts.', 'Long coastline.'],
    neighbors: { N: 'IN-AP', S: 'IO_OCN_IN', E: 'BAY_BENGAL_IN', W: 'IN-KL' },
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-AP',
    name: 'Andhra Pradesh State',
    centroid: [15.9129, 79.7400],
    description_5pt: ['Southeastern Indian state.', 'Known for its rich history and natural beauty.', 'Capital is Amaravati.', 'Rice bowl of India.', 'Long coastline.'],
    neighbors: { N: 'IN-OR', S: 'IN-TN', E: 'BAY_BENGAL_IN', W: 'IN-KA' },
    boundary_type: 'State',
  },
  {
    feature_id: 'IN-OR',
    name: 'Odisha State',
    centroid: [20.9517, 85.0985],
    description_5pt: ['Eastern Indian state.', 'Known for its tribal cultures and ancient temples.', 'Capital is Bhubaneswar.', 'Long coastline on the Bay of Bengal.', 'Rich in natural resources.'],
    neighbors: { N: 'IN-CT', S: 'IN-AP', E: 'BAY_BENGAL_IN', W: 'IN-CT' },
    boundary_type: 'State',
  },
  {
    feature_id: 'ARABIAN_SEA_IN',
    name: 'Arabian Sea',
    centroid: [18, 65],
    description_5pt: ['A region of the Indian Ocean.', 'Major marine trade route.', 'Borders India, Pakistan, Iran, and Arabian Peninsula.', 'Known for strong monsoon winds.', 'Diverse marine ecosystem.'],
    neighbors: { N: 'IN-GJ', S: 'IO_OCN_IN', E: 'IN-MH', W: 'ARABIAN_SEA_IN' },
    boundary_type: 'Sea',
  },
  {
    feature_id: 'BAY_BENGAL_IN',
    name: 'Bay of Bengal',
    centroid: [15, 88],
    description_5pt: ['Northeastern part of the Indian Ocean.', 'Borders India, Bangladesh, Myanmar, and Sri Lanka.', 'Receives water from major rivers.', 'Prone to tropical cyclones.', 'Rich in marine resources.'],
    neighbors: { N: 'IN-OR', S: 'IO_OCN_IN', E: 'MM', W: 'IN-AP' },
    boundary_type: 'Sea',
  },
  {
    feature_id: 'IO_OCN_IN',
    name: 'Indian Ocean',
    centroid: [7, 78],
    description_5pt: ['Southern border of India.', 'Connects to the Arabian Sea and Bay of Bengal.', 'Warm waters.', 'Important for maritime trade.', 'Rich marine biodiversity.'],
    neighbors: { N: 'IN-KL', S: 'IO_OCN_IN', E: 'BAY_BENGAL_IN', W: 'ARABIAN_SEA_IN' },
    boundary_type: 'Ocean',
  },

  // --- INDIA DISTRICTS FEATURES ---
  {
    feature_id: 'IN-GJ-AHM',
    name: 'Ahmedabad District',
    centroid: [23.0225, 72.5714],
    description_5pt: ['Largest city in Gujarat.', 'Known for textile industry.', 'Historical city.', 'Sabarmati Ashram location.', 'Cultural hub.'],
    neighbors: { N: 'IN-GJ-GND', S: 'IN-GJ-KH', E: 'IN-GJ-AN', W: 'IN-GJ-SR' },
    boundary_type: 'District',
  },
  {
    feature_id: 'IN-GJ-GND',
    name: 'Gandhinagar District',
    centroid: [23.2156, 72.6362],
    description_5pt: ['Capital of Gujarat.', 'Planned city.', 'Akshardham Temple.', 'Gift City location.', 'Green city.'],
    neighbors: { N: 'IN-RJ-UDR', S: 'IN-GJ-AHM', E: 'IN-GJ-AN', W: 'IN-GJ-SR' }, // IN-RJ-UDR = Udaipur (Rajasthan)
    boundary_type: 'District',
  },
  {
    feature_id: 'IN-GJ-KH',
    name: 'Kheda District',
    centroid: [22.7093, 72.7667],
    description_5pt: ['Central Gujarat district.', 'Known for agriculture.', 'Historically significant.', 'Mahi River flows through it.', 'Rich cultural heritage.'],
    neighbors: { N: 'IN-GJ-AHM', S: 'IN-GJ-AN', E: 'IN-GJ-AN', W: 'IN-GJ-SR' },
    boundary_type: 'District',
  },
  {
    feature_id: 'IN-GJ-AN',
    name: 'Anand District',
    centroid: [22.5600, 72.9300],
    description_5pt: ['Known as the "Milk Capital of India".', 'Home to Amul Dairy.', 'Educational hub.', 'Rich agricultural land.', 'Historic temples.'],
    neighbors: { N: 'IN-GJ-KH', S: 'IN-GJ-VD', E: 'IN-GJ-BD', W: 'IN-GJ-KH' }, // IN-GJ-VD = Vadodara, IN-GJ-BD = Bharuch
    boundary_type: 'District',
  },
  {
    feature_id: 'IN-GJ-VD',
    name: 'Vadodara District',
    centroid: [22.3072, 73.1812],
    description_5pt: ['Industrial and cultural capital of Gujarat.', 'Known for Laxmi Vilas Palace.', 'Educational hub.', 'Vishwamitri River passes through it.', 'Royal heritage.'],
    neighbors: { N: 'IN-GJ-AN', S: 'IN-GJ-BD', E: 'IN-MP-JAB', W: 'IN-GJ-AN' }, // IN-MP-JAB = Jhabua (MP)
    boundary_type: 'District',
  },
  {
    feature_id: 'IN-GJ-BD',
    name: 'Bharuch District',
    centroid: [21.7000, 72.9900],
    description_5pt: ['Ancient port city on the Narmada River.', 'Known for its historical significance.', 'Industrial center.', 'Rich in biodiversity.', 'Gateway to the Arabian Sea.'],
    neighbors: { N: 'IN-GJ-VD', S: 'ARABIAN_SEA_IN', E: 'IN-MH-SUR', W: 'ARABIAN_SEA_IN' }, // IN-MH-SUR = Surat (Maharashtra)
    boundary_type: 'District',
  },
  {
    feature_id: 'IN-GJ-SR',
    name: 'Surendranagar District',
    centroid: [22.7300, 71.6600],
    description_5pt: ['Historical district in Gujarat.', 'Known for its cotton and ceramic industries.', 'Home to Nal Sarovar Bird Sanctuary.', 'Dry climate.', 'Ancient temples.'],
    neighbors: { N: 'IN-RJ-BHJ', S: 'ARABIAN_SEA_IN', E: 'IN-GJ-AHM', W: 'IN-GJ-KCH' }, // IN-RJ-BHJ = Bhuj (Rajasthan/Kutch)
    boundary_type: 'District',
  },
];

class GeoDataService {
  private worldFeaturesMap: Record<string, Feature> = {};
  private indiaStatesFeaturesMap: Record<string, Feature> = {};
  private indiaDistrictsFeaturesMap: Record<string, Feature> = {};

  constructor() {
    worldFeatures.forEach(feature => {
      this.worldFeaturesMap[feature.feature_id] = feature;
    });

    // Populate indiaStatesFeaturesMap by filtering worldFeatures
    worldFeatures
      .filter(feature => feature.feature_id.startsWith('IN-') && feature.boundary_type === 'State')
      .forEach(feature => {
        this.indiaStatesFeaturesMap[feature.feature_id] = feature;
      });

    // Populate indiaDistrictsFeaturesMap by filtering worldFeatures (assuming 'IN-GJ-' for now)
    worldFeatures
      .filter(feature => feature.feature_id.startsWith('IN-GJ-') && feature.boundary_type === 'District')
      .forEach(feature => {
        this.indiaDistrictsFeaturesMap[feature.feature_id] = feature;
      });
  }

  /**
   * Retrieves all features for a given map level.
   * @param mapLevel The desired map level.
   * @returns An array of features for that level.
   */
  public getFeatures(mapLevel: MapLevel): Feature[] {
    switch (mapLevel) {
      case MapLevel.WORLD:
        return Object.values(this.worldFeaturesMap);
      case MapLevel.INDIA_STATES:
        return Object.values(this.indiaStatesFeaturesMap);
      case MapLevel.INDIA_DISTRICTS:
        return Object.values(this.indiaDistrictsFeaturesMap);
      default:
        return [];
    }
  }

  /**
   * Retrieves a single feature by its ID for the current map level.
   * @param featureId The unique identifier of the feature.
   * @param mapLevel The current map level.
   * @returns The Feature object or undefined if not found.
   */
  public getFeatureById(featureId: string, mapLevel: MapLevel): Feature | undefined {
    switch (mapLevel) {
      case MapLevel.WORLD:
        return this.worldFeaturesMap[featureId];
      case MapLevel.INDIA_STATES:
        return this.indiaStatesFeaturesMap[featureId];
      case MapLevel.INDIA_DISTRICTS:
        return this.indiaDistrictsFeaturesMap[featureId];
      default:
        return undefined;
    }
  }

  /**
   * Gets the neighboring feature's ID or null in a given direction.
   * All features are potentially navigable. A `null` neighbor indicates a true "edge of the map" for that direction.
   * @param currentFeatureId The ID of the current feature.
   * @param direction The direction to look for a neighbor.
   * @param mapLevel The current map level.
   * @returns The feature ID of the neighbor, or null if no navigable neighbor exists.
   */
  public getNeighbor(currentFeatureId: string, direction: Direction, mapLevel: MapLevel): string | null {
    const currentFeature = this.getFeatureById(currentFeatureId, mapLevel);
    if (!currentFeature) {
      console.warn(`Feature with ID ${currentFeatureId} not found at level ${mapLevel}.`);
      return null;
    }
    const neighborId = currentFeature.neighbors[direction];

    // Check if the neighborId points to a valid feature that exists in the current map level's data.
    // This is important if a neighbor is defined, but it might be outside the current zoom level,
    // or if the data is inconsistent.
    if (neighborId) {
      const neighborFeature = this.getFeatureById(neighborId, mapLevel);
      if (neighborFeature) {
        return neighborId;
      } else {
        // If neighborId is present but the feature doesn't exist in the current map, treat as null for navigation purposes
        console.warn(`Defined neighbor '${neighborId}' for '${currentFeatureId}' not found at level ${mapLevel}. Treating as map edge.`);
        return null;
      }
    }
    return null; // Explicitly return null if no neighbor is defined
  }
}

export const geoDataService = new GeoDataService();