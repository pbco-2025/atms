// services/audioService.ts
import { Direction, DirectionalSoundConfig } from '../types';
import { AUDIO_PARAMS } from '../constants';

/**
 * Manages the Web Audio API context, listener, and panner for spatial audio effects.
 */
export class AudioEngine {
  private audioContext: AudioContext | null = null;
  private listener: AudioListener | null = null;
  private panner: PannerNode | null = null;
  private masterGain: GainNode | null = null;
  private isInitialized = false;
  private currentOceanAmbientSource: OscillatorNode | null = null;
  private oceanAmbientGainNode: GainNode | null = null;

  /**
   * Initializes the AudioContext, AudioListener, and PannerNode.
   * This should be called on a user gesture (e.g., first interaction) to enable audio playback.
   */
  public init(): void {
    if (this.isInitialized) {
      return;
    }
    this.audioContext = new AudioContext();
    this.listener = this.audioContext.listener;

    // Set listener fixed at origin (0,0,0) with identity orientation
    this.listener.positionX.setValueAtTime(0, this.audioContext.currentTime);
    this.listener.positionY.setValueAtTime(0, this.audioContext.currentTime);
    this.listener.positionZ.setValueAtTime(0, this.audioContext.currentTime);
    this.listener.forwardX.setValueAtTime(0, this.audioContext.currentTime);
    this.listener.forwardY.setValueAtTime(0, this.audioContext.currentTime);
    this.listener.forwardZ.setValueAtTime(-1, this.audioContext.currentTime); // Looking towards negative Z
    this.listener.upX.setValueAtTime(0, this.audioContext.currentTime);
    this.listener.upY.setValueAtTime(1, this.audioContext.currentTime);
    this.listener.upZ.setValueAtTime(0, this.audioContext.currentTime);

    this.panner = this.audioContext.createPanner();
    this.panner.panningModel = 'HRTF'; // High quality spatialization
    this.panner.distanceModel = 'inverse';
    this.panner.refDistance = 1;
    this.panner.maxDistance = 10000;
    this.panner.rolloffFactor = 1;
    this.panner.coneInnerAngle = 360;
    this.panner.coneOuterAngle = 0;
    this.panner.coneOuterGain = 0;

    // Master gain node for overall volume control
    this.masterGain = this.audioContext.createGain();
    this.masterGain.gain.setValueAtTime(AUDIO_PARAMS.gain, this.audioContext.currentTime);
    this.masterGain.connect(this.audioContext.destination);

    this.panner.connect(this.masterGain);

    this.isInitialized = true;
    console.log('AudioEngine initialized.');
  }

  /**
   * Plays a simple oscillator sound through the PannerNode for directional cues.
   * @param direction The cardinal direction to place the sound source.
   * @private
   */
  private playSimpleDirectionalSound(direction: Direction): void {
    if (!this.audioContext || !this.panner || !this.masterGain) {
      console.warn('AudioEngine not initialized. Cannot play sound.');
      return;
    }

    const { currentTime } = this.audioContext;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'sine';
    oscillator.frequency.setValueAtTime(AUDIO_PARAMS.frequency, currentTime);
    gainNode.gain.setValueAtTime(0.5, currentTime); // Initial gain for the individual sound

    oscillator.connect(gainNode);
    gainNode.connect(this.panner); // Connect to the spatial panner

    // Update panner position based on direction.
    // Listener is at (0,0,0). Sound source moves relative to listener.
    const distance = 1.0; // Fixed distance for perceived direction
    switch (direction) {
      case 'N':
        this.panner.positionY.setValueAtTime(distance, currentTime); // Forward
        this.panner.positionX.setValueAtTime(0, currentTime);
        break;
      case 'S':
        this.panner.positionY.setValueAtTime(-distance, currentTime); // Backward
        this.panner.positionX.setValueAtTime(0, currentTime);
        break;
      case 'E':
        this.panner.positionX.setValueAtTime(distance, currentTime); // Right
        this.panner.positionY.setValueAtTime(0, currentTime);
        break;
      case 'W':
        this.panner.positionX.setValueAtTime(-distance, currentTime); // Left
        this.panner.positionY.setValueAtTime(0, currentTime);
        break;
    }
    this.panner.positionZ.setValueAtTime(-0.5, currentTime); // Slightly behind to enhance 3D effect

    oscillator.start(currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, currentTime + AUDIO_PARAMS.duration); // Fade out
    oscillator.stop(currentTime + AUDIO_PARAMS.duration);

    // Reset panner position after the sound plays to prepare for the next directional sound
    setTimeout(() => {
      if (this.panner && this.audioContext) {
        this.panner.positionX.setValueAtTime(0, this.audioContext.currentTime);
        this.panner.positionY.setValueAtTime(0, this.audioContext.currentTime);
        this.panner.positionZ.setValueAtTime(0, this.audioContext.currentTime);
      }
    }, AUDIO_PARAMS.duration * 1000 + 50); // A little after the sound ends
  }

  /**
   * Plays a distinct sound for hitting a map boundary.
   */
  public playBoundarySound(): void {
    if (!this.audioContext || !this.masterGain) {
      console.warn('AudioEngine not initialized. Cannot play sound.');
      return;
    }

    const { currentTime } = this.audioContext;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'triangle'; // Use a different waveform
    oscillator.frequency.setValueAtTime(AUDIO_PARAMS.boundaryFrequency, currentTime);
    gainNode.gain.setValueAtTime(0.7, currentTime); // Slightly louder

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain); // Connect directly to master gain (non-spatial)

    oscillator.start(currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, currentTime + AUDIO_PARAMS.duration * 1.5);
    oscillator.stop(currentTime + AUDIO_PARAMS.duration * 1.5);
  }

  /**
   * Plays a directional sound cue.
   * @param direction The cardinal direction of movement.
   */
  public playDirectionalSound(direction: Direction): void {
    if (!this.audioContext || !this.panner || !this.masterGain) {
      console.warn('AudioEngine not initialized. Cannot play directional sound.');
      return;
    }
    // Fix: Pass the direction directly as the argument to playSimpleDirectionalSound
    this.playSimpleDirectionalSound(direction);
  }

  /**
   * Plays a sound indicating a level change (zoom in/out).
   */
  public playLevelChangeSound(): void {
    if (!this.audioContext || !this.masterGain) {
      console.warn('AudioEngine not initialized. Cannot play sound.');
      return;
    }
    this.stopOceanAmbient(); // Stop ambient sound if zooming

    const { currentTime } = this.audioContext;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'square';
    oscillator.frequency.setValueAtTime(AUDIO_PARAMS.frequency * 1.5, currentTime); // Higher pitch
    gainNode.gain.setValueAtTime(0.6, currentTime);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start(currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, currentTime + AUDIO_PARAMS.duration * 2);
    oscillator.stop(currentTime + AUDIO_PARAMS.duration * 2);
  }

  /**
   * Plays an ambient sound for ocean features.
   */
  public playOceanAmbient(): void {
    if (!this.audioContext || !this.masterGain) {
      console.warn('AudioEngine not initialized. Cannot play ocean ambient sound.');
      return;
    }
    this.stopOceanAmbient(); // Ensure only one ambient sound plays

    const { currentTime } = this.audioContext;
    this.currentOceanAmbientSource = this.audioContext.createOscillator();
    this.oceanAmbientGainNode = this.audioContext.createGain();

    this.currentOceanAmbientSource.type = 'sine';
    this.currentOceanAmbientSource.frequency.setValueAtTime(AUDIO_PARAMS.oceanAmbientFrequency, currentTime);
    this.oceanAmbientGainNode.gain.setValueAtTime(AUDIO_PARAMS.gain * 0.5, currentTime); // Lower gain for ambient

    this.currentOceanAmbientSource.connect(this.oceanAmbientGainNode);
    this.oceanAmbientGainNode.connect(this.masterGain);
    this.currentOceanAmbientSource.start(currentTime);
  }

  /**
   * Stops the currently playing ocean ambient sound.
   */
  public stopOceanAmbient(): void {
    if (this.currentOceanAmbientSource) {
      this.currentOceanAmbientSource.stop();
      this.currentOceanAmbientSource.disconnect();
      this.currentOceanAmbientSource = null;
    }
    if (this.oceanAmbientGainNode) {
      this.oceanAmbientGainNode.disconnect();
      this.oceanAmbientGainNode = null;
    }
  }

  /**
   * Plays a distinct sound for river features.
   */
  public playRiverSound(): void {
    if (!this.audioContext || !this.masterGain) {
      console.warn('AudioEngine not initialized. Cannot play river sound.');
      return;
    }
    this.stopOceanAmbient();

    const { currentTime } = this.audioContext;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'sawtooth'; // Distinct waveform for river
    oscillator.frequency.setValueAtTime(AUDIO_PARAMS.riverFrequency, currentTime);
    gainNode.gain.setValueAtTime(0.6, currentTime);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start(currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, currentTime + AUDIO_PARAMS.duration * 1.5);
    oscillator.stop(currentTime + AUDIO_PARAMS.duration * 1.5);
  }

  /**
   * Plays a distinct sound for mountain range features.
   */
  public playMountainSound(): void {
    if (!this.audioContext || !this.masterGain) {
      console.warn('AudioEngine not initialized. Cannot play mountain sound.');
      return;
    }
    this.stopOceanAmbient();

    const { currentTime } = this.audioContext;
    const oscillator = this.audioContext.createOscillator();
    const gainNode = this.audioContext.createGain();

    oscillator.type = 'square'; // Distinct waveform for mountains
    oscillator.frequency.setValueAtTime(AUDIO_PARAMS.mountainFrequency, currentTime);
    gainNode.gain.setValueAtTime(0.6, currentTime);

    oscillator.connect(gainNode);
    gainNode.connect(this.masterGain);

    oscillator.start(currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, currentTime + AUDIO_PARAMS.duration * 1.5);
    oscillator.stop(currentTime + AUDIO_PARAMS.duration * 1.5);
  }

  /**
   * Stops all active audio playback and closes the AudioContext.
   */
  public stopAll(): void {
    this.stopOceanAmbient(); // Stop ambient sound before closing context
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().then(() => {
        console.log('AudioContext closed.');
        this.isInitialized = false;
        this.audioContext = null;
        this.listener = null;
        this.panner = null;
        this.masterGain = null;
      });
    }
  }

  /**
   * Public getter for the initialization status.
   * @returns True if the audio engine is initialized, false otherwise.
   */
  public isAudioInitialized(): boolean {
    return this.isInitialized;
  }
}

export const audioEngine = new AudioEngine();